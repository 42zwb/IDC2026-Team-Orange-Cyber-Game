param(
    [ValidateSet("red", "blue")]
    [string]$Side = "red"
)

$ErrorActionPreference = "Stop"

# Always run from the directory containing this script and the official scene.
Set-Location -LiteralPath $PSScriptRoot

# The participant controller reads this variable when it is imported.
$env:IDC2026_SIDE = $Side

Write-Host "Starting IDC2026 Cyber Game on side: $Side"
& python .\run_match.py
$exitCode = $LASTEXITCODE
if ($null -eq $exitCode) {
    $exitCode = 0
}
exit $exitCode

