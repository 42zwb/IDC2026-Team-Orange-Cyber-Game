import time
from dataclasses import dataclass

import numpy as np
import mujoco
import mujoco.viewer


# ============================================================
# IDC2026 Cyber Game - FIELD SIDE
# ============================================================
#
# This file belongs to the organizer / field side.
#
# Left two goals  : RED team
# Right two goals : BLUE team
#
# The participant-side program (user_side_go2.py) supplies only:
#   1. ball initial conditions at reset, and
#   2. Go2 actuator commands during the match.
#
# The field side owns:
#   - MuJoCo model/data and mj_step()
#   - gravity, contact and friction
#   - goal configuration
#   - goal-passage detection
#   - RED / BLUE scoring
#   - scoreboards
#   - match timer
#   - viewer
#
# Goal colors are not fixed.
#
# At every reset:
#   1. the RED-side goal arrangement is selected randomly,
#   2. the BLUE-side arrangement is generated as the mirror image of RED
#      across the field center line,
#   3. the matching seated puppets move together with the goal colors.
#
# The participant does not need a camera for the basic Cyber Game sample.
# field_side.py provides a semantic field observation containing the current
# goal-color assignment and fixed goal positions. This information is passed
# to user_side_go2.py through the normal observation interface.
# ============================================================

MATCH_DURATION = 180.0

RED = "red"
BLUE = "blue"

# ----------------------------------------------------------------
# Start B visualization
# ----------------------------------------------------------------
#
# The Cyber World rule requires the complete initial Go2 + participant
# mechanism to fit inside:
#
#     X direction = 0.80 m
#     Y direction = 0.50 m
#     Z direction = 0.80 m
#
# The current default Go2 start pose is centered at the RED Start B
# location:
#
#     x = -2.00 m
#     y = +3.00 m
#
# The four goal centers are symmetric about approximately x=-0.01 m.
# The BLUE Start B visualization is therefore the mirror image of RED
# about the same center line.
#
# The boxes themselves are visualization-only MuJoCo sites in the scene
# XML. They have no collision/contact behavior.
#
# Their positions are fixed explicitly. field_side.py does NOT move them
# at runtime.
# ----------------------------------------------------------------

FIELD_CENTER_X = -0.01

START_B_SIZE = np.array(
    [0.80, 0.50, 0.80],
    dtype=float,
)

START_B_CENTER = {
    RED: np.array(
        [-2.00, 3.00, 0.60],
        dtype=float,
    ),
    BLUE: np.array(
        [1.98, 3.00, 0.60],
        dtype=float,
    ),
}

# The current MuJoCo visualization uses Yellow / White as visual
# proxies for the final rule-book Orange / Silver colors.
YELLOW = "yellow"
WHITE = "white"

COLOR_RGBA = {
    YELLOW: np.array([1.0, 1.0, 0.0, 1.0], dtype=float),
    WHITE: np.array([1.0, 1.0, 1.0, 1.0], dtype=float),
}

TEAM_ACTIVE_RGBA = {
    RED: np.array([1.00, 0.08, 0.08, 1.0], dtype=float),
    BLUE: np.array([0.08, 0.25, 1.00, 1.0], dtype=float),
}

TEAM_INACTIVE_RGBA = {
    RED: np.array([0.22, 0.015, 0.015, 1.0], dtype=float),
    BLUE: np.array([0.015, 0.045, 0.22, 1.0], dtype=float),
}


@dataclass(frozen=True)
class GoalSlot:
    """Fixed physical goal slot.

    Color is intentionally NOT stored here because color changes at reset.
    """

    key: str
    team: str
    site_name: str
    display_name: str

    # The two part3 mesh geoms forming the physical left/right side plates.
    side_geom_names: tuple

    # All three visible goal geoms whose color must change together.
    color_geom_names: tuple

    # Transparent collector located behind the goal.
    collector_body_name: str
    collector_geom_names: dict

    # Position used for the fixed seated puppet assigned to this slot.
    puppet_position: tuple


@dataclass(frozen=True)
class BallSpec:
    body_name: str
    joint_name: str
    color: str
    display_name: str


# ============================================================
# Physical goal slots
# ============================================================
#
# World-X order:
#
#     RED-1      RED-2       BLUE-1      BLUE-2
#     left outer left inner  right inner  right outer
#
# Mirror pairs across the field center:
#
#     RED-1 <-> BLUE-2
#     RED-2 <-> BLUE-1
# ============================================================

GOAL_SLOTS = (
    GoalSlot(
        key="red_1",
        team=RED,
        site_name="score_gate_red_1",
        display_name="RED-1",
        side_geom_names=(
            "red_goal_1_side_a",
            "red_goal_1_side_b",
        ),
        color_geom_names=(
            "red_goal_1_side_a",
            "red_goal_1_cross",
            "red_goal_1_side_b",
        ),
        collector_body_name="collector_red_1",
        collector_geom_names={
            "left": "collector_red_1_side_left",
            "right": "collector_red_1_side_right",
            "bottom": "collector_red_1_bottom",
            "back": "collector_red_1_back",
        },
        puppet_position=(-0.52, 0.030, 0.40),
    ),
    GoalSlot(
        key="red_2",
        team=RED,
        site_name="score_gate_red_2",
        display_name="RED-2",
        side_geom_names=(
            "red_goal_2_side_a",
            "red_goal_2_side_b",
        ),
        color_geom_names=(
            "red_goal_2_side_a",
            "red_goal_2_cross",
            "red_goal_2_side_b",
        ),
        collector_body_name="collector_red_2",
        collector_geom_names={
            "left": "collector_red_2_side_left",
            "right": "collector_red_2_side_right",
            "bottom": "collector_red_2_bottom",
            "back": "collector_red_2_back",
        },
        puppet_position=(-0.22, 0.030, 0.40),
    ),
    GoalSlot(
        key="blue_1",
        team=BLUE,
        site_name="score_gate_blue_1",
        display_name="BLUE-1",
        side_geom_names=(
            "blue_goal_1_side_a",
            "blue_goal_1_side_b",
        ),
        color_geom_names=(
            "blue_goal_1_side_a",
            "blue_goal_1_cross",
            "blue_goal_1_side_b",
        ),
        collector_body_name="collector_blue_1",
        collector_geom_names={
            "left": "collector_blue_1_side_left",
            "right": "collector_blue_1_side_right",
            "bottom": "collector_blue_1_bottom",
            "back": "collector_blue_1_back",
        },
        puppet_position=(0.18, 0.030, 0.40),
    ),
    GoalSlot(
        key="blue_2",
        team=BLUE,
        site_name="score_gate_blue_2",
        display_name="BLUE-2",
        side_geom_names=(
            "blue_goal_2_side_a",
            "blue_goal_2_side_b",
        ),
        color_geom_names=(
            "blue_goal_2_side_a",
            "blue_goal_2_cross",
            "blue_goal_2_side_b",
        ),
        collector_body_name="collector_blue_2",
        collector_geom_names={
            "left": "collector_blue_2_side_left",
            "right": "collector_blue_2_side_right",
            "bottom": "collector_blue_2_bottom",
            "back": "collector_blue_2_back",
        },
        puppet_position=(0.48, 0.030, 0.40),
    ),
)


BALLS = (
    BallSpec("yellow_1", "yellow_1_joint", YELLOW, "YELLOW-1"),
    BallSpec("white_1", "white_1_joint", WHITE, "WHITE-1"),
    BallSpec("yellow_2", "yellow_2_joint", YELLOW, "YELLOW-2"),
    BallSpec("white_2", "white_2_joint", WHITE, "WHITE-2"),
)


# Default four-ball scoring-test paths.
# These are used only to print the expected result for the default test.
TEST_PATH_SLOT = {
    "yellow_1": "red_1",
    "white_1": "red_2",
    "yellow_2": "blue_1",
    "white_2": "blue_2",
}


def object_id(model, obj_type, name):
    """Return a MuJoCo object ID and fail early if the name is missing."""

    obj_id = mujoco.mj_name2id(
        model,
        obj_type,
        name,
    )

    if obj_id < 0:
        raise RuntimeError(
            f"MuJoCo object not found: {name}"
        )

    return int(obj_id)


def opposite_color(color):
    """Return the other Cyber Game goal color."""

    return WHITE if color == YELLOW else YELLOW


# ============================================================
# Goal geometry and randomized configuration
# ============================================================

class GoalConfigurationManager:
    """Manage physical opening geometry and reset-time goal assignment.

    There are two separate jobs here.

    1) Geometric calibration
       ---------------------
       The collector opening must match the real goal opening, including
       the STL side-plate thickness.  XML geom positions alone are not
       sufficient because the STL mesh can have an offset from its geom
       frame.

       Therefore the actual compiled part3 mesh vertices are transformed
       to world coordinates.  For the two physical side plates:

           inner-left  edge = max X of the left side plate
           inner-right edge = min X of the right side plate

       The score-gate width and transparent collector width are then
       derived from these exact inner edges.

    2) Reset-time configuration
       ------------------------
       Only the RED-side arrangement is selected randomly.

       Each side always has exactly:
           - one YELLOW goal
           - one WHITE goal

       The BLUE-side arrangement is then generated as the mirror image of
       RED across the field center line:

           RED-1 <-> BLUE-2
           RED-2 <-> BLUE-1

       A reset performs a new random RED-side draw. Because this is a true
       random draw, the same legal arrangement may occur on consecutive
       resets.
    """

    COLLECTOR_WALL_HALF_THICKNESS = 0.006

    # Fallback values are only a safety net if STL calibration cannot
    # be completed.  A warning is printed whenever fallback is used.
    FALLBACK = {
        "red_1": (-0.51, 0.055),
        "red_2": (-0.21, 0.055),
        "blue_1": (0.19, 0.055),
        "blue_2": (0.49, 0.055),
    }

    def __init__(self, model, data):
        self.model = model
        self.data = data

        self.rng = np.random.default_rng()
        self.site_visible = False

        self.goal_colors = {}
        self.opening_geometry = {}

        self.site_ids = {}
        self.color_geom_ids = {}
        self.side_geom_ids = {}
        self.collector_body_ids = {}
        self.collector_geom_ids = {}

        for slot in GOAL_SLOTS:
            self.site_ids[slot.key] = object_id(
                model,
                mujoco.mjtObj.mjOBJ_SITE,
                slot.site_name,
            )

            self.color_geom_ids[slot.key] = [
                object_id(
                    model,
                    mujoco.mjtObj.mjOBJ_GEOM,
                    name,
                )
                for name in slot.color_geom_names
            ]

            self.side_geom_ids[slot.key] = [
                object_id(
                    model,
                    mujoco.mjtObj.mjOBJ_GEOM,
                    name,
                )
                for name in slot.side_geom_names
            ]

            self.collector_body_ids[slot.key] = object_id(
                model,
                mujoco.mjtObj.mjOBJ_BODY,
                slot.collector_body_name,
            )

            self.collector_geom_ids[slot.key] = {
                role: object_id(
                    model,
                    mujoco.mjtObj.mjOBJ_GEOM,
                    name,
                )
                for role, name
                in slot.collector_geom_names.items()
            }

        # One yellow and one white puppet are used on each team side.
        self.puppet_body_ids = {
            YELLOW: (
                object_id(
                    model,
                    mujoco.mjtObj.mjOBJ_BODY,
                    "puppet_yellow_1",
                ),
                object_id(
                    model,
                    mujoco.mjtObj.mjOBJ_BODY,
                    "puppet_yellow_2",
                ),
            ),
            WHITE: (
                object_id(
                    model,
                    mujoco.mjtObj.mjOBJ_BODY,
                    "puppet_white_1",
                ),
                object_id(
                    model,
                    mujoco.mjtObj.mjOBJ_BODY,
                    "puppet_white_2",
                ),
            ),
        }

        self.calibrate_goal_openings()

    def _mesh_world_x_extent(self, geom_id):
        """Return [minX, maxX] of a mesh geom in world coordinates."""

        if (
            self.model.geom_type[geom_id]
            != mujoco.mjtGeom.mjGEOM_MESH
        ):
            raise RuntimeError(
                "Goal side geom is not a mesh."
            )

        mesh_id = int(
            self.model.geom_dataid[geom_id]
        )

        if mesh_id < 0:
            raise RuntimeError(
                "Invalid mesh data ID."
            )

        vertex_adr = int(
            self.model.mesh_vertadr[mesh_id]
        )
        vertex_num = int(
            self.model.mesh_vertnum[mesh_id]
        )

        vertices = np.asarray(
            self.model.mesh_vert[
                vertex_adr:vertex_adr + vertex_num
            ],
            dtype=float,
        )

        rotation = np.asarray(
            self.data.geom_xmat[geom_id],
            dtype=float,
        ).reshape(3, 3)

        position = np.asarray(
            self.data.geom_xpos[geom_id],
            dtype=float,
        )

        world_vertices = (
            rotation @ vertices.T
        ).T + position

        return (
            float(np.min(world_vertices[:, 0])),
            float(np.max(world_vertices[:, 0])),
        )

    def calibrate_goal_openings(self):
        """Measure the real STL opening and align detector/collector.

        The collector side-wall inner faces are placed at exactly the
        same X coordinates as the physical goal side-plate inner edges.
        """

        mujoco.mj_forward(
            self.model,
            self.data,
        )

        print(
            "\n[FIELD] Goal-opening calibration "
            "from the actual STL side plates:"
        )

        for slot in GOAL_SLOTS:
            try:
                extents = [
                    self._mesh_world_x_extent(geom_id)
                    for geom_id
                    in self.side_geom_ids[slot.key]
                ]

                # Sort the two physical side plates from left to right.
                extents.sort(
                    key=lambda e: 0.5 * (e[0] + e[1])
                )

                left_plate = extents[0]
                right_plate = extents[1]

                # The inner edge of the left plate is its maximum X.
                # The inner edge of the right plate is its minimum X.
                opening_left = left_plate[1]
                opening_right = right_plate[0]

                if opening_right <= opening_left:
                    raise RuntimeError(
                        "Derived side-plate extents overlap: "
                        f"left={left_plate}, "
                        f"right={right_plate}"
                    )

                center_x = (
                    opening_left + opening_right
                ) * 0.5

                half_width = (
                    opening_right - opening_left
                ) * 0.5

                # Reject obviously impossible results instead of silently
                # building a badly aligned collector.
                if not (
                    0.025 <= half_width <= 0.12
                ):
                    raise RuntimeError(
                        "Derived opening half-width "
                        f"{half_width:.4f} m is unreasonable."
                    )

                source = "STL"

            except Exception as exc:
                center_x, half_width = (
                    self.FALLBACK[slot.key]
                )

                opening_left = (
                    center_x - half_width
                )
                opening_right = (
                    center_x + half_width
                )

                source = "FALLBACK"

                print(
                    f"  WARNING {slot.display_name}: "
                    f"STL calibration failed: {exc}"
                )

            self.opening_geometry[slot.key] = {
                "left": opening_left,
                "right": opening_right,
                "center": center_x,
                "half_width": half_width,
                "source": source,
            }

            # --------------------------------------------------------
            # Score-gate plane
            # --------------------------------------------------------
            # The site belongs to the table body, whose origin is the
            # world origin.  Therefore site_pos X is the world X value.
            site_id = self.site_ids[slot.key]

            self.model.site_pos[
                site_id,
                0,
            ] = center_x

            self.model.site_size[
                site_id,
                0,
            ] = half_width

            # --------------------------------------------------------
            # Transparent collector
            # --------------------------------------------------------
            #
            # For a wall with half-thickness t:
            #
            # left wall center  = -(half_width + t)
            # inner right face  = center + t = -half_width
            #
            # right wall center = +(half_width + t)
            # inner left face   = center - t = +half_width
            #
            # Therefore the collector opening is exactly the same as
            # the measured physical goal opening.
            collector_body_id = (
                self.collector_body_ids[slot.key]
            )

            self.model.body_pos[
                collector_body_id,
                0,
            ] = center_x

            t = (
                self.COLLECTOR_WALL_HALF_THICKNESS
            )

            collector_ids = (
                self.collector_geom_ids[slot.key]
            )

            self.model.geom_pos[
                collector_ids["left"],
                0,
            ] = -(half_width + t)

            self.model.geom_pos[
                collector_ids["right"],
                0,
            ] = +(half_width + t)

            # Bottom/back extend to the outside of both transparent
            # side walls.
            outer_half_width = (
                half_width + 2.0 * t
            )

            self.model.geom_size[
                collector_ids["bottom"],
                0,
            ] = outer_half_width

            self.model.geom_size[
                collector_ids["back"],
                0,
            ] = outer_half_width

            print(
                f"  {slot.display_name:6s}: "
                f"opening=["
                f"{opening_left:+.4f}, "
                f"{opening_right:+.4f}] m, "
                f"center={center_x:+.4f}, "
                f"width={2.0 * half_width:.4f} m "
                f"[{source}]"
            )

        mujoco.mj_forward(
            self.model,
            self.data,
        )

    def randomize(self):
        """Randomize RED and mirror the result onto BLUE.

        RED side
        --------
        RED-1 / RED-2 are randomly assigned:

            YELLOW / WHITE
        or
            WHITE / YELLOW

        BLUE side
        ---------
        BLUE is not randomized independently.

        The BLUE configuration is the geometric mirror of RED:

            RED-1 <-> BLUE-2
            RED-2 <-> BLUE-1

        Every reset performs a fresh random RED-side draw, so the same
        arrangement may legitimately appear twice in a row.
        """

        red_1_color = (
            YELLOW
            if int(
                self.rng.integers(
                    0,
                    2,
                )
            ) == 0
            else WHITE
        )

        red_2_color = opposite_color(
            red_1_color
        )

        # Mirror RED across the field center line.
        blue_1_color = red_2_color
        blue_2_color = red_1_color

        self.goal_colors = {
            "red_1": red_1_color,
            "red_2": red_2_color,
            "blue_1": blue_1_color,
            "blue_2": blue_2_color,
        }

        self._apply_goal_colors()
        self._move_puppets()
        self._apply_site_colors()

        mujoco.mj_forward(
            self.model,
            self.data,
        )

        print(
            "\n[FIELD] Goal colors after reset:"
        )

        for slot in GOAL_SLOTS:
            print(
                f"  {slot.display_name:6s}: "
                f"{self.goal_colors[slot.key].upper()}"
            )

        print(
            "  BLUE is the mirror image of RED."
        )

    def _apply_goal_colors(self):
        """Change all visible mesh pieces of each goal."""

        for slot in GOAL_SLOTS:
            rgba = COLOR_RGBA[
                self.goal_colors[slot.key]
            ]

            for geom_id in (
                self.color_geom_ids[slot.key]
            ):
                self.model.geom_rgba[
                    geom_id
                ] = rgba

    def _move_puppets(self):
        """Move yellow/white puppets to the randomized goal slots.

        Puppet *_1 is the RED-side instance.
        Puppet *_2 is the BLUE-side instance.
        """

        slot_by_key = {
            slot.key: slot
            for slot in GOAL_SLOTS
        }

        for color in (
            YELLOW,
            WHITE,
        ):
            red_key = next(
                key
                for key in ("red_1", "red_2")
                if (
                    self.goal_colors[key]
                    == color
                )
            )

            blue_key = next(
                key
                for key in ("blue_1", "blue_2")
                if (
                    self.goal_colors[key]
                    == color
                )
            )

            (
                red_puppet_body_id,
                blue_puppet_body_id,
            ) = self.puppet_body_ids[color]

            self.model.body_pos[
                red_puppet_body_id
            ] = np.asarray(
                slot_by_key[
                    red_key
                ].puppet_position,
                dtype=float,
            )

            self.model.body_pos[
                blue_puppet_body_id
            ] = np.asarray(
                slot_by_key[
                    blue_key
                ].puppet_position,
                dtype=float,
            )

    def _apply_site_colors(self):
        """Color optional score-gate visualization to match each goal."""

        alpha = (
            0.22
            if self.site_visible
            else 0.0
        )

        for slot in GOAL_SLOTS:
            color = self.goal_colors.get(
                slot.key,
                WHITE,
            )

            rgba = COLOR_RGBA[
                color
            ].copy()

            rgba[3] = alpha

            self.model.site_rgba[
                self.site_ids[slot.key]
            ] = rgba

    def set_site_visibility(self, visible):
        """Show/hide the four score-detection planes."""

        self.site_visible = bool(
            visible
        )

        self._apply_site_colors()

        print(
            "[FIELD] Score-gate planes: "
            f"{'VISIBLE' if self.site_visible else 'HIDDEN'}"
        )


# ============================================================
# Score recognition
# ============================================================

class ScoreManager:
    """Detect actual ball passage and maintain RED/BLUE scores.

    A goal event occurs only when the ball center crosses the goal site
    from +local-Y to -local-Y and the interpolated crossing point lies
    inside the X-Z aperture.

    Goal color is read from the current reset configuration.

    Matched color:
        +1 to the team owning the physical goal slot.

    Mismatched color:
        +0, but the passage is logged.

    Each ball can generate only one scoring event.
    """

    def __init__(self, model, data):
        self.model = model
        self.data = data

        self.goal_info = []

        for slot in GOAL_SLOTS:
            site_id = object_id(
                model,
                mujoco.mjtObj.mjOBJ_SITE,
                slot.site_name,
            )

            self.goal_info.append(
                (slot, site_id)
            )

        self.ball_info = []

        for ball in BALLS:
            body_id = object_id(
                model,
                mujoco.mjtObj.mjOBJ_BODY,
                ball.body_name,
            )

            self.ball_info.append(
                (ball, body_id)
            )

        self.reset(
            {
                slot.key: WHITE
                for slot in GOAL_SLOTS
            }
        )

    def reset(self, goal_colors):
        """Clear the match score and load the current goal colors."""

        self.goal_colors = dict(
            goal_colors
        )

        self.team_scores = {
            RED: 0,
            BLUE: 0,
        }

        self.processed_balls = set()
        self.previous_local = {}
        self.events = []

    def _ball_local_to_goal(
        self,
        body_id,
        site_id,
    ):
        """Express ball position in the local score-site frame."""

        p_ball = self.data.xpos[
            body_id
        ].copy()

        p_goal = self.data.site_xpos[
            site_id
        ].copy()

        R_goal = (
            self.data.site_xmat[
                site_id
            ]
            .reshape(3, 3)
            .copy()
        )

        return (
            R_goal.T
            @ (p_ball - p_goal)
        )

    def update(self, match_time):
        """Check all unprocessed balls for a new goal crossing."""

        if match_time > MATCH_DURATION:
            return []

        new_events = []

        for (
            ball,
            body_id,
        ) in self.ball_info:

            if (
                ball.body_name
                in self.processed_balls
            ):
                continue

            for (
                slot,
                site_id,
            ) in self.goal_info:

                key = (
                    ball.body_name,
                    slot.key,
                )

                current = (
                    self._ball_local_to_goal(
                        body_id,
                        site_id,
                    )
                )

                previous = (
                    self.previous_local.get(
                        key
                    )
                )

                self.previous_local[
                    key
                ] = current.copy()

                if previous is None:
                    continue

                crossed = (
                    previous[1] > 0.0
                    and current[1] <= 0.0
                )

                if not crossed:
                    continue

                denominator = (
                    previous[1]
                    - current[1]
                )

                if (
                    abs(denominator)
                    < 1.0e-12
                ):
                    continue

                # Interpolate the position exactly at local Y = 0.
                alpha = (
                    previous[1]
                    / denominator
                )

                crossing = (
                    previous
                    + alpha
                    * (current - previous)
                )

                half_x = float(
                    self.model.site_size[
                        site_id,
                        0,
                    ]
                )

                half_z = float(
                    self.model.site_size[
                        site_id,
                        2,
                    ]
                )

                inside = (
                    abs(crossing[0])
                    <= half_x
                    and
                    abs(crossing[2])
                    <= half_z
                )

                if not inside:
                    continue

                goal_color = (
                    self.goal_colors[
                        slot.key
                    ]
                )

                matched_color = (
                    ball.color
                    == goal_color
                )

                if matched_color:
                    self.team_scores[
                        slot.team
                    ] += 1

                event = {
                    "time": float(
                        match_time
                    ),
                    "ball": ball.display_name,
                    "ball_color": ball.color,
                    "goal": slot.display_name,
                    "goal_key": slot.key,
                    "goal_color": goal_color,
                    "team": slot.team,
                    "matched_color": (
                        matched_color
                    ),
                    "red_score": (
                        self.team_scores[RED]
                    ),
                    "blue_score": (
                        self.team_scores[BLUE]
                    ),
                    "cross_x": float(
                        crossing[0]
                    ),
                    "cross_z": float(
                        crossing[2]
                    ),
                }

                self.events.append(
                    event
                )

                new_events.append(
                    event
                )

                self.processed_balls.add(
                    ball.body_name
                )

                break

        return new_events


# ============================================================
# Two-digit RED / BLUE scoreboards
# ============================================================

class TeamScoreboard:
    """Seven-segment scoreboard whose active color identifies the team."""

    DIGIT_SEGMENTS = {
        0: "ABCDEF",
        1: "BC",
        2: "ABDEG",
        3: "ABCDG",
        4: "BCFG",
        5: "ACDFG",
        6: "ACDEFG",
        7: "ABC",
        8: "ABCDEFG",
        9: "ABCDFG",
    }

    def __init__(
        self,
        model,
        team,
    ):
        self.model = model
        self.team = team

        self.active = (
            TEAM_ACTIVE_RGBA[team]
        )

        self.inactive = (
            TEAM_INACTIVE_RGBA[team]
        )

        self.geom_ids = {
            "tens": {},
            "ones": {},
        }

        for digit_name in (
            "tens",
            "ones",
        ):
            for segment in "ABCDEFG":
                geom_name = (
                    f"score_{team}_"
                    f"{digit_name}_"
                    f"{segment}"
                )

                self.geom_ids[
                    digit_name
                ][segment] = object_id(
                    model,
                    mujoco.mjtObj.mjOBJ_GEOM,
                    geom_name,
                )

        self.current_score = None
        self.set_score(0)

    def _set_digit(
        self,
        digit_name,
        value,
    ):
        active_segments = (
            self.DIGIT_SEGMENTS[
                int(value)
            ]
        )

        for (
            segment,
            geom_id,
        ) in self.geom_ids[
            digit_name
        ].items():

            self.model.geom_rgba[
                geom_id
            ] = (
                self.active
                if segment
                in active_segments
                else self.inactive
            )

    def set_score(self, score):
        """Update the two displayed digits."""

        score = int(
            np.clip(
                score,
                0,
                99,
            )
        )

        if score == self.current_score:
            return

        self.current_score = score

        self._set_digit(
            "tens",
            score // 10,
        )

        self._set_digit(
            "ones",
            score % 10,
        )


# ============================================================
# Three-digit in-field match timer
# ============================================================

class MatchTimerDisplay:
    """Display the remaining match time as integer seconds.

    The scene contains a three-digit seven-segment display between the
    RED and BLUE scoreboards.

    The display counts:

        180, 179, 178, ... , 001, 000

    The countdown is based on MuJoCo simulation time.

    When the display reaches 000, FieldRuntime stops advancing physics.
    Therefore participant motion and scoring also stop at game end.
    """

    DIGIT_SEGMENTS = {
        0: "ABCDEF",
        1: "BC",
        2: "ABDEG",
        3: "ABCDG",
        4: "BCFG",
        5: "ACDFG",
        6: "ACDEFG",
        7: "ABC",
        8: "ABCDEFG",
        9: "ABCDFG",
    }

    ACTIVE_RGBA = np.array(
        [1.00, 0.85, 0.10, 1.0],
        dtype=float,
    )

    INACTIVE_RGBA = np.array(
        [0.12, 0.10, 0.01, 1.0],
        dtype=float,
    )

    def __init__(
        self,
        model,
    ):
        self.model = model
        self.current_value = None

        self.geom_ids = {
            "hundreds": {},
            "tens": {},
            "ones": {},
        }

        for digit_name in (
            "hundreds",
            "tens",
            "ones",
        ):
            for segment in "ABCDEFG":
                self.geom_ids[
                    digit_name
                ][segment] = object_id(
                    model,
                    mujoco.mjtObj.mjOBJ_GEOM,
                    f"timer_{digit_name}_{segment}",
                )

        self.set_seconds(
            int(MATCH_DURATION)
        )

    def _set_digit(
        self,
        digit_name,
        value,
    ):
        active_segments = (
            self.DIGIT_SEGMENTS[
                int(value)
            ]
        )

        for segment, geom_id in (
            self.geom_ids[
                digit_name
            ].items()
        ):
            self.model.geom_rgba[
                geom_id
            ] = (
                self.ACTIVE_RGBA
                if segment in active_segments
                else self.INACTIVE_RGBA
            )

    def set_seconds(
        self,
        remaining_seconds,
    ):
        """Update the display only when the integer value changes."""

        value = int(
            np.clip(
                remaining_seconds,
                0,
                999,
            )
        )

        if value == self.current_value:
            return

        self.current_value = value

        self._set_digit(
            "hundreds",
            value // 100,
        )

        self._set_digit(
            "tens",
            (value // 10) % 10,
        )

        self._set_digit(
            "ones",
            value % 10,
        )


# ============================================================
# Field-side four-ball scoring test
# ============================================================

class ScoringTestLauncher:
    """Apply a short force to the four test balls.

    This helper never changes qpos and never awards points.
    It only applies a physical external force.

    Because the goal colors change after reset, the same four physical
    ball paths produce different RED/BLUE score results.
    """

    LAUNCH_TIMES = {
        "yellow_1": 2.0,
        "white_1": 4.0,
        "yellow_2": 6.0,
        "white_2": 8.0,
    }

    FORCE_Y = -0.12
    FORCE_DURATION = 0.45

    def __init__(
        self,
        model,
        data,
    ):
        self.model = model
        self.data = data
        self.enabled = False
        self.announced = set()

        self.body_ids = {
            ball.body_name: object_id(
                model,
                mujoco.mjtObj.mjOBJ_BODY,
                ball.body_name,
            )
            for ball in BALLS
        }

    def reset(self):
        """Clear per-run launch messages."""

        self.announced.clear()

    def apply_forces(
        self,
        match_time,
    ):
        """Apply the configured -Y force pulse at each launch time."""

        if not self.enabled:
            return

        for ball in BALLS:
            name = ball.body_name
            t0 = self.LAUNCH_TIMES[
                name
            ]
            t1 = (
                t0
                + self.FORCE_DURATION
            )

            if t0 <= match_time < t1:
                body_id = (
                    self.body_ids[name]
                )

                self.data.xfrc_applied[
                    body_id,
                    1,
                ] += self.FORCE_Y

                if (
                    name
                    not in self.announced
                ):
                    self.announced.add(
                        name
                    )

                    p = self.data.xpos[
                        body_id
                    ]

                    print(
                        f"[TEST t={match_time:5.2f}] "
                        f"launch {ball.display_name}: "
                        f"pos=("
                        f"{p[0]:+.3f}, "
                        f"{p[1]:+.3f}, "
                        f"{p[2]:+.3f})"
                    )


# ============================================================
# Field runtime
# ============================================================

class FieldRuntime:
    """Own and run the complete field-side simulation."""

    def __init__(
        self,
        xml_path,
    ):
        self.xml_path = xml_path

        self.model = (
            mujoco.MjModel.from_xml_path(
                xml_path
            )
        )

        self.data = mujoco.MjData(
            self.model
        )

        # MjData-derived world coordinates such as geom_xpos are not
        # valid until forward kinematics has been evaluated once.
        mujoco.mj_forward(
            self.model,
            self.data,
        )

        self.goal_configuration = (
            GoalConfigurationManager(
                self.model,
                self.data,
            )
        )

        self.score_manager = (
            ScoreManager(
                self.model,
                self.data,
            )
        )

        self.scoreboards = {
            RED: TeamScoreboard(
                self.model,
                RED,
            ),
            BLUE: TeamScoreboard(
                self.model,
                BLUE,
            ),
        }

        self.timer_display = (
            MatchTimerDisplay(
                self.model
            )
        )

        self.test_launcher = (
            ScoringTestLauncher(
                self.model,
                self.data,
            )
        )

        self.controller = None
        self.reset_requested = False
        self.match_over_announced = False

        print(
            "\n[FIELD] MuJoCo gravity = "
            f"{self.model.opt.gravity.tolist()} "
            "m/s^2"
        )

    def attach_controller(
        self,
        controller,
    ):
        """Connect the participant controller and perform the first reset."""

        self.controller = controller
        self.reset()

    def _apply_user_robot_initial_state(
        self,
    ):
        """Apply the participant-defined Go2 base state once at reset.

        This function is the field-side counterpart of:

            controller.initial_robot_state()

        The participant defines the desired initial state, but field_side.py
        owns the MuJoCo simulation and therefore performs the actual qpos /
        qvel write.

        ----------------------------------------------------------------
        GO2 BASE FREE-JOINT LAYOUT
        ----------------------------------------------------------------

        Go2 base_link is attached to the world through a MuJoCo free joint.

        Its generalized position is:

            qpos =
                [x, y, z, qw, qx, qy, qz]

        Its generalized velocity is:

            qvel =
                [vx, vy, vz, wx, wy, wz]

        where:

            x, y, z
                world position of base_link

            qw, qx, qy, qz
                world orientation quaternion

            vx, vy, vz
                world translational velocity

            wx, wy, wz
                world angular velocity

        ----------------------------------------------------------------
        WHY THIS IS APPLIED BEFORE BALL PLACEMENT
        ----------------------------------------------------------------

        user_mechanism.xml is attached rigidly to base_link.

        Therefore changing the Go2 initial pose changes the world pose of
        every participant-mechanism body and site.

        Some balls can be initialized from a mechanism site, for example:

            "site": "user_ball_slot_1"

        For that reason the reset order must be:

            1. apply Go2 base pose
            2. apply Go2 leg posture
            3. update forward kinematics
            4. resolve participant-mechanism site positions
            5. place balls

        Reversing this order would place the ball using an outdated site
        world position.

        ----------------------------------------------------------------
        WHEN THIS FUNCTION RUNS
        ----------------------------------------------------------------

        The function is called only during reset.

        After the match starts, field_side.py does not repeatedly overwrite
        the Go2 base pose. The robot moves according to MuJoCo physics and
        the actuator commands returned by the participant controller.
        """

        if self.controller is None:
            return

        # Older participant programs may not implement this optional
        # interface. In that case, keep the XML-defined base initial state.
        if not hasattr(
            self.controller,
            "initial_robot_state",
        ):
            return

        state = (
            self.controller
            .initial_robot_state()
        )

        # Locate base_link by name instead of assuming a fixed body index.
        base_body_id = object_id(
            self.model,
            mujoco.mjtObj.mjOBJ_BODY,
            "base_link",
        )

        joint_count = int(
            self.model.body_jntnum[
                base_body_id
            ]
        )

        if joint_count < 1:
            raise RuntimeError(
                "Go2 base_link has no joint."
            )

        # The first joint attached to base_link is expected to be the free
        # joint that represents the floating robot base.
        joint_id = int(
            self.model.body_jntadr[
                base_body_id
            ]
        )

        if (
            self.model.jnt_type[
                joint_id
            ]
            != mujoco.mjtJoint.mjJNT_FREE
        ):
            raise RuntimeError(
                "The first base_link joint is not a free joint."
            )

        qpos_adr = int(
            self.model.jnt_qposadr[
                joint_id
            ]
        )

        qvel_adr = int(
            self.model.jnt_dofadr[
                joint_id
            ]
        )

        position = np.asarray(
            state["position"],
            dtype=float,
        )

        quaternion = np.asarray(
            state["quaternion"],
            dtype=float,
        )

        linear_velocity = np.asarray(
            state["linear_velocity"],
            dtype=float,
        )

        angular_velocity = np.asarray(
            state["angular_velocity"],
            dtype=float,
        )

        # Validate the interface before writing into MuJoCo arrays.
        if position.shape != (3,):
            raise ValueError(
                "Go2 initial position must have 3 elements."
            )

        if quaternion.shape != (4,):
            raise ValueError(
                "Go2 initial quaternion must have 4 elements."
            )

        if linear_velocity.shape != (3,):
            raise ValueError(
                "Go2 initial linear velocity must have 3 elements."
            )

        if angular_velocity.shape != (3,):
            raise ValueError(
                "Go2 initial angular velocity must have 3 elements."
            )

        quaternion_norm = np.linalg.norm(
            quaternion
        )

        if quaternion_norm <= 1.0e-12:
            raise ValueError(
                "Go2 initial quaternion must not be zero."
            )

        # Normalize again on the field side as a defensive check. This keeps
        # the field robust even if a participant implementation bypasses the
        # normalization normally performed in user_side_go2.py.
        quaternion = (
            quaternion
            / quaternion_norm
        )

        # Free-joint qpos:
        #
        #     [x, y, z, qw, qx, qy, qz]
        self.data.qpos[
            qpos_adr:
            qpos_adr + 3
        ] = position

        self.data.qpos[
            qpos_adr + 3:
            qpos_adr + 7
        ] = quaternion

        # Free-joint qvel:
        #
        #     [vx, vy, vz, wx, wy, wz]
        self.data.qvel[
            qvel_adr:
            qvel_adr + 3
        ] = linear_velocity

        self.data.qvel[
            qvel_adr + 3:
            qvel_adr + 6
        ] = angular_velocity

        print(
            "[USER INIT] Go2 base_link: "
            f"pos=("
            f"{position[0]:+.3f}, "
            f"{position[1]:+.3f}, "
            f"{position[2]:+.3f}) "
            f"quat=("
            f"{quaternion[0]:+.4f}, "
            f"{quaternion[1]:+.4f}, "
            f"{quaternion[2]:+.4f}, "
            f"{quaternion[3]:+.4f})"
        )

    def _apply_user_ball_initial_state(
        self,
    ):
        """Apply participant-defined ball states once at reset.

        A ball may be initialized in either of two ways.

        1. Absolute world position:

               "position": [x, y, z]

        2. Relative to a named MuJoCo site:

               "site": "user_ball_slot_1"
               "position_offset": [dx, dy, dz]

           The offset is expressed in the site's local frame.

        Site-based placement is useful for participant mechanisms because
        the ball follows the mechanism definition automatically when the
        Go2 start pose or mechanism geometry changes.
        """

        if self.controller is None:
            return

        if not hasattr(
            self.controller,
            "initial_ball_state",
        ):
            return

        requested = (
            self.controller
            .initial_ball_state()
        )

        known_ball_names = {
            ball.body_name
            for ball in BALLS
        }

        unknown_names = (
            set(requested.keys())
            - known_ball_names
        )

        if unknown_names:
            raise ValueError(
                "Unknown user-configured ball names: "
                + ", ".join(
                    sorted(unknown_names)
                )
            )

        # The Go2 reset posture has already been written at this point.
        # Update forward kinematics before reading any attachment site.
        mujoco.mj_forward(
            self.model,
            self.data,
        )

        for ball in BALLS:
            if ball.body_name not in requested:
                continue

            config = requested[
                ball.body_name
            ]

            joint_id = object_id(
                self.model,
                mujoco.mjtObj.mjOBJ_JOINT,
                ball.joint_name,
            )

            if (
                self.model.jnt_type[
                    joint_id
                ]
                != mujoco.mjtJoint.mjJNT_FREE
            ):
                raise RuntimeError(
                    f"{ball.joint_name} is not a free joint."
                )

            qpos_adr = int(
                self.model.jnt_qposadr[
                    joint_id
                ]
            )

            qvel_adr = int(
                self.model.jnt_dofadr[
                    joint_id
                ]
            )

            # --------------------------------------------------------
            # Resolve the initial position.
            # --------------------------------------------------------
            if "site" in config:
                site_name = str(
                    config["site"]
                )

                site_id = object_id(
                    self.model,
                    mujoco.mjtObj.mjOBJ_SITE,
                    site_name,
                )

                site_position = (
                    self.data.site_xpos[
                        site_id
                    ].copy()
                )

                site_rotation = (
                    self.data.site_xmat[
                        site_id
                    ]
                    .reshape(3, 3)
                    .copy()
                )

                local_offset = np.asarray(
                    config.get(
                        "position_offset",
                        [0.0, 0.0, 0.0],
                    ),
                    dtype=float,
                )

                if local_offset.shape != (3,):
                    raise ValueError(
                        f"{ball.body_name}: "
                        "position_offset must have 3 elements."
                    )

                position = (
                    site_position
                    + site_rotation
                    @ local_offset
                )

                position_source = (
                    f"site={site_name}"
                )

            elif "position" in config:
                position = np.asarray(
                    config["position"],
                    dtype=float,
                )

                if position.shape != (3,):
                    raise ValueError(
                        f"{ball.body_name}: "
                        "position must have 3 elements."
                    )

                position_source = "world position"

            else:
                raise ValueError(
                    f"{ball.body_name}: specify either "
                    "'position' or 'site'."
                )

            quaternion = np.asarray(
                config.get(
                    "quaternion",
                    [1.0, 0.0, 0.0, 0.0],
                ),
                dtype=float,
            )

            linear_velocity = np.asarray(
                config.get(
                    "linear_velocity",
                    [0.0, 0.0, 0.0],
                ),
                dtype=float,
            )

            angular_velocity = np.asarray(
                config.get(
                    "angular_velocity",
                    [0.0, 0.0, 0.0],
                ),
                dtype=float,
            )

            if quaternion.shape != (4,):
                raise ValueError(
                    f"{ball.body_name}: "
                    "quaternion must have 4 elements."
                )

            if linear_velocity.shape != (3,):
                raise ValueError(
                    f"{ball.body_name}: "
                    "linear_velocity must have 3 elements."
                )

            if angular_velocity.shape != (3,):
                raise ValueError(
                    f"{ball.body_name}: "
                    "angular_velocity must have 3 elements."
                )

            quaternion_norm = np.linalg.norm(
                quaternion
            )

            if quaternion_norm <= 1.0e-12:
                raise ValueError(
                    f"{ball.body_name}: "
                    "quaternion norm is zero."
                )

            quaternion = (
                quaternion
                / quaternion_norm
            )

            # Free-joint qpos:
            # [x, y, z, qw, qx, qy, qz]
            self.data.qpos[
                qpos_adr:
                qpos_adr + 3
            ] = position

            self.data.qpos[
                qpos_adr + 3:
                qpos_adr + 7
            ] = quaternion

            # Free-joint qvel:
            # [vx, vy, vz, wx, wy, wz]
            self.data.qvel[
                qvel_adr:
                qvel_adr + 3
            ] = linear_velocity

            self.data.qvel[
                qvel_adr + 3:
                qvel_adr + 6
            ] = angular_velocity

            print(
                "[USER INIT] "
                f"{ball.body_name}: "
                f"pos=("
                f"{position[0]:+.3f}, "
                f"{position[1]:+.3f}, "
                f"{position[2]:+.3f}) "
                f"from {position_source}"
            )

    def _print_expected_scoring_test(
        self,
    ):
        """Print the default-test score expected from current goal colors."""

        expected = {
            RED: 0,
            BLUE: 0,
        }

        slot_by_key = {
            slot.key: slot
            for slot in GOAL_SLOTS
        }

        ball_by_name = {
            ball.body_name: ball
            for ball in BALLS
        }

        print(
            "\n[FIELD] Default four-ball "
            "scoring-test expectation "
            "for this reset:"
        )

        for ball_name in (
            "yellow_1",
            "white_1",
            "yellow_2",
            "white_2",
        ):
            slot_key = (
                TEST_PATH_SLOT[
                    ball_name
                ]
            )

            ball = ball_by_name[
                ball_name
            ]

            slot = slot_by_key[
                slot_key
            ]

            goal_color = (
                self.goal_configuration
                .goal_colors[
                    slot_key
                ]
            )

            matched = (
                ball.color
                == goal_color
            )

            if matched:
                expected[
                    slot.team
                ] += 1

            print(
                f"  {ball.display_name:8s} "
                f"-> {slot.display_name:6s} "
                f"({goal_color.upper():6s}) : "
                f"{'+1' if matched else '+0'}"
            )

        print(
            f"  Expected RED={expected[RED]:02d}, "
            f"BLUE={expected[BLUE]:02d}"
        )

    def reset(self):
        """Reset the complete match state in a deterministic order.

        Reset order is important because several initial conditions depend
        on other objects.

        The sequence is:

            1. Reset MuJoCo data to the XML-defined state.
            2. Reset participant-controller internal memory.
            3. Apply the participant-defined Go2 base pose and velocity.
            4. Apply the participant-defined Go2 leg-joint posture.
            5. Update forward kinematics.
            6. Resolve participant-mechanism sites and place the balls.
            7. Randomize RED goal colors and mirror them onto BLUE.
            8. Reset scoring state, scoreboards, and match timer.

        In particular, the Go2 base pose must be applied before resolving
        a site such as user_ball_slot_1 because that site is attached to
        the participant mechanism, which moves together with base_link.
        """

        # Step 1: return the complete MuJoCo state to its XML-defined reset
        # condition. Participant initial conditions are applied afterwards.
        mujoco.mj_resetData(
            self.model,
            self.data,
        )

        if self.controller is not None:
            # Step 2: clear participant-controller memory such as integral
            # states from the previous match.
            self.controller.reset()

            # Step 3: set the participant-defined floating-base pose and
            # velocity. user_mechanism.xml moves with base_link.
            self._apply_user_robot_initial_state()

            # Step 4: apply the Go2 leg posture once at reset.
            for (
                qpos_adr,
                qvel_adr,
                actuator_id,
                q0,
            ) in (
                self.controller
                .initial_joint_state()
            ):
                self.data.qpos[
                    qpos_adr
                ] = q0

                self.data.qvel[
                    qvel_adr
                ] = 0.0

                self.data.ctrl[
                    actuator_id
                ] = q0

        # Apply participant-defined ball initial conditions once.
        self._apply_user_ball_initial_state()

        # Change the field condition only on the field side.
        self.goal_configuration.randomize()

        self.data.xfrc_applied[:] = 0.0

        self.test_launcher.reset()

        self.score_manager.reset(
            self.goal_configuration
            .goal_colors
        )

        self.scoreboards[
            RED
        ].set_score(0)

        self.scoreboards[
            BLUE
        ].set_score(0)

        self.timer_display.set_seconds(
            int(MATCH_DURATION)
        )

        mujoco.mj_forward(
            self.model,
            self.data,
        )

        # Prime previous positions so a real crossing can be detected
        # immediately on the next simulation step.
        self.score_manager.update(
            0.0
        )

        self.match_over_announced = False

        print(
            "\n[FIELD] Match reset"
        )

        print(
            "[FIELD] Ball positions are "
            "not overwritten after reset."
        )

        if self.test_launcher.enabled:
            self._print_expected_scoring_test()
        else:
            print(
                "[FIELD] Four-ball scoring-test launcher is OFF. "
                "Press 'd' to enable it."
            )

    def _make_field_observation(
        self,
        match_time,
    ):
        """Return semantic field information for participant control.

        This is the basic non-camera sensing interface used by the Cyber
        Game sample.

        The participant receives the CURRENT field state, not a precomputed
        action or "correct-goal" command.

        Available information includes:
            - current goal colors,
            - fixed goal-center positions,
            - remaining match time,
            - RED / BLUE Start B centers and size.

        All arrays are returned as copies so participant code cannot modify
        organizer-side geometry through the observation dictionary.
        """

        remaining_seconds = int(
            np.ceil(
                max(
                    0.0,
                    MATCH_DURATION
                    - float(match_time),
                )
            )
        )

        goals = {}

        for slot in GOAL_SLOTS:
            site_id = (
                self.goal_configuration
                .site_ids[
                    slot.key
                ]
            )

            goals[
                slot.key
            ] = {
                "team": slot.team,
                "color": (
                    self.goal_configuration
                    .goal_colors[
                        slot.key
                    ]
                ),
                "position": (
                    self.data.site_xpos[
                        site_id
                    ].copy()
                ),
            }

        return {
            "remaining_time_s": remaining_seconds,
            "match_duration_s": int(
                MATCH_DURATION
            ),
            "goals": goals,
            "start_b": {
                RED: {
                    "center": (
                        START_B_CENTER[
                            RED
                        ].copy()
                    ),
                    "size": (
                        START_B_SIZE.copy()
                    ),
                },
                BLUE: {
                    "center": (
                        START_B_CENTER[
                            BLUE
                        ].copy()
                    ),
                    "size": (
                        START_B_SIZE.copy()
                    ),
                },
            },
        }

    def _apply_user_command(
        self,
        command,
    ):
        """Validate and apply participant actuator commands.

        Preferred participant interface:

            {
                "FR_hip": target,
                "FR_thigh": target,
                ...
                "user_some_actuator": target,
            }

        Allowed names:
            - the 12 Go2 leg actuator names
            - actuator names beginning with "user_"

        The "user_" namespace is created automatically by the
        user_mechanism.xml attachment prefix.

        Integer actuator IDs are still accepted for backward compatibility,
        but new participant code should return actuator names.
        """

        if command is None:
            return

        for actuator_key, value in command.items():

            # --------------------------------------------------------
            # Resolve actuator name / ID.
            # --------------------------------------------------------
            if isinstance(
                actuator_key,
                str,
            ):
                actuator_name = actuator_key

                participant_owned = (
                    actuator_name.startswith(
                        ("FR_", "FL_", "RR_", "RL_")
                    )
                    or actuator_name.startswith(
                        "user_"
                    )
                )

                if not participant_owned:
                    print(
                        "[FIELD] Ignored non-participant actuator: "
                        f"{actuator_name}"
                    )
                    continue

                actuator_id = (
                    mujoco.mj_name2id(
                        self.model,
                        mujoco.mjtObj.mjOBJ_ACTUATOR,
                        actuator_name,
                    )
                )

                if actuator_id < 0:
                    print(
                        "[FIELD] Unknown participant actuator: "
                        f"{actuator_name}"
                    )
                    continue

            else:
                # Backward compatibility with older user-side examples.
                actuator_id = int(
                    actuator_key
                )

                if not (
                    0
                    <= actuator_id
                    < self.model.nu
                ):
                    continue

                actuator_name = (
                    mujoco.mj_id2name(
                        self.model,
                        mujoco.mjtObj.mjOBJ_ACTUATOR,
                        actuator_id,
                    )
                )

                if actuator_name is None:
                    continue

                participant_owned = (
                    actuator_name.startswith(
                        ("FR_", "FL_", "RR_", "RL_")
                    )
                    or actuator_name.startswith(
                        "user_"
                    )
                )

                if not participant_owned:
                    continue

            # --------------------------------------------------------
            # Final field-side safety clipping.
            # --------------------------------------------------------
            value = float(value)

            if (
                self.model
                .actuator_ctrllimited[
                    actuator_id
                ]
            ):
                low, high = (
                    self.model
                    .actuator_ctrlrange[
                        actuator_id
                    ]
                )

                value = float(
                    np.clip(
                        value,
                        low,
                        high,
                    )
                )

            self.data.ctrl[
                actuator_id
            ] = value

    def _print_score_events(
        self,
        events,
    ):
        """Print each physical goal-passage event."""

        for event in events:
            result = (
                "MATCHED COLOR +1"
                if event[
                    "matched_color"
                ]
                else "COLOR MISMATCH +0"
            )

            print(
                f"[SCORE t={event['time']:5.2f}] "
                f"{event['ball']} "
                f"-> {event['goal']} "
                f"({event['goal_color'].upper()}) : "
                f"{result} | "
                f"cross=("
                f"x={event['cross_x']:+.3f}, "
                f"z={event['cross_z']:+.3f}) | "
                f"RED={event['red_score']:02d} "
                f"BLUE={event['blue_score']:02d}"
            )

    def run(self):
        """Open the passive viewer and execute the field-side loop."""

        if self.controller is None:
            raise RuntimeError(
                "Attach a user controller "
                "before run()."
            )

        def key_callback(
            keycode,
        ):
            try:
                key = chr(
                    keycode
                ).lower()
            except (
                ValueError,
                TypeError,
            ):
                return

            if key == "r":
                self.reset_requested = True
                return

            if key == "d":
                self.test_launcher.enabled = (
                    not
                    self.test_launcher.enabled
                )

                print(
                    "[FIELD] Four-ball "
                    "scoring test: "
                    f"{'ON' if self.test_launcher.enabled else 'OFF'}"
                )
                return

            if key == "v":
                self.goal_configuration.set_site_visibility(
                    not
                    self.goal_configuration.site_visible
                )
                return

            self.controller.handle_key(
                key
            )

        with mujoco.viewer.launch_passive(
            self.model,
            self.data,
            key_callback=key_callback,
        ) as viewer:

            # Keep the camera setting previously requested for this project.
            viewer.cam.lookat[:] = np.array(
                [0.0, 0.4, 0.25]
            )
            viewer.cam.distance = 4.0
            viewer.cam.azimuth = 90
            viewer.cam.elevation = -25

            print(
                "\nControls:"
            )
            print(
                "  r : reset match and randomize RED goal colors"
            )
            print(
                "  d : four-ball scoring test ON/OFF"
            )
            print(
                "  v : score-gate planes ON/OFF"
            )
            print(
                "  g : Go2 gait ON/OFF"
            )
            print(
                "  p : Go2 integral compensation ON/OFF"
            )

            next_status_time = 0.0

            while viewer.is_running():
                wall_start = (
                    time.perf_counter()
                )

                if self.reset_requested:
                    self.reset_requested = False
                    self.reset()

                dt = float(
                    self.model.opt.timestep
                )

                match_time = float(
                    self.data.time
                )

                remaining_seconds = int(
                    np.ceil(
                        max(
                            0.0,
                            MATCH_DURATION
                            - match_time,
                        )
                    )
                )

                self.timer_display.set_seconds(
                    remaining_seconds
                )

                if (
                    match_time
                    >= MATCH_DURATION
                ):
                    self.timer_display.set_seconds(
                        0
                    )

                    if (
                        not
                        self.match_over_announced
                    ):
                        self.match_over_announced = True

                        print(
                            "[FIELD] TIME UP: "
                            f"RED="
                            f"{self.score_manager.team_scores[RED]:02d} "
                            f"BLUE="
                            f"{self.score_manager.team_scores[BLUE]:02d}"
                        )

                    viewer.sync()
                    time.sleep(
                        0.02
                    )
                    continue

                # ----------------------------------------------------
                # USER SIDE
                # ----------------------------------------------------
                field_observation = (
                    self._make_field_observation(
                        match_time
                    )
                )

                command = (
                    self.controller
                    .compute_control(
                        match_time,
                        dt,
                        field_observation,
                    )
                )

                self._apply_user_command(
                    command
                )

                # ----------------------------------------------------
                # FIELD SIDE
                # ----------------------------------------------------
                self.data.xfrc_applied[:] = 0.0

                self.test_launcher.apply_forces(
                    match_time
                )

                # Only the field side advances physics.
                mujoco.mj_step(
                    self.model,
                    self.data,
                )

                events = (
                    self.score_manager
                    .update(
                        float(
                            self.data.time
                        )
                    )
                )

                if events:
                    self._print_score_events(
                        events
                    )

                    self.scoreboards[
                        RED
                    ].set_score(
                        self.score_manager
                        .team_scores[RED]
                    )

                    self.scoreboards[
                        BLUE
                    ].set_score(
                        self.score_manager
                        .team_scores[BLUE]
                    )

                viewer.sync()

                if (
                    self.data.time
                    >= next_status_time
                ):
                    remaining = max(
                        0.0,
                        MATCH_DURATION
                        - self.data.time,
                    )

                    print(
                        f"[FIELD] "
                        f"t={self.data.time:6.2f} "
                        f"RED="
                        f"{self.score_manager.team_scores[RED]:02d} "
                        f"BLUE="
                        f"{self.score_manager.team_scores[BLUE]:02d} "
                        f"remaining="
                        f"{remaining:6.1f}s"
                    )

                    next_status_time += 1.0

                elapsed = (
                    time.perf_counter()
                    - wall_start
                )

                sleep_time = (
                    dt - elapsed
                )

                if sleep_time > 0.0:
                    time.sleep(
                        sleep_time
                    )
