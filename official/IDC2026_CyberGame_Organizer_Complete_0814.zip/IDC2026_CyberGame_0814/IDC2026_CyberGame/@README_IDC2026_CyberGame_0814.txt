IDC2026 Cyber Game simulation v7
=================================

PURPOSE
-------

v7 adds an explicit participant-mechanism interface.

Participants can now develop two independent items:

    1. user_side_go2.py
       Participant software / control.

    2. user_mechanism.xml
       Participant mechanical design.

The organizer-side field, scoring, randomized goals, scoreboards, and
match timing remain in field_side.py and scene_IDC2026_scoring_v7.xml.


PARTICIPANT MECHANISM
---------------------

The supplied sample user_mechanism.xml is a passive open-top box mounted
on the Go2 back.

go2.xml loads the mechanism as a separate MuJoCo model:

    <model
      name="user_mechanism_model"
      file="user_mechanism.xml"/>

and attaches it directly to base_link:

    <attach
      model="user_mechanism_model"
      body="mount_root"
      prefix="user_"/>

Therefore participants normally edit only user_mechanism.xml.

The mechanism coordinate frame is the Go2 base_link frame:

    +X : Go2 forward
    +Y : Go2 left
    +Z : Go2 upward


SAMPLE BALL IN THE BOX
----------------------

The sample mechanism defines:

    site name="ball_slot_1"

After attachment, its compiled name becomes:

    user_ball_slot_1

user_side_go2.py places yellow_1 at that site during reset:

    "yellow_1": {
        "site": "user_ball_slot_1",
        ...
    }

This is preferable to hard-coding a world position because the ball
placement follows the mechanism and Go2 pose automatically.

The field resolves the site world position once at reset. After that,
the ball is a normal free body and is not position-controlled.


STANDALONE MECHANISM DEVELOPMENT
--------------------------------

The participant mechanism can be inspected without the IDC field or Go2
mesh assets.

Run:

    python -m mujoco.viewer --mjcf=user_mechanism_test.xml

The test scene contains:

    - a simple dummy Go2 base,
    - user_mechanism.xml,
    - one sample yellow ball.

This allows geometry development before running the full game.


ADDING A PARTICIPANT ACTUATOR
-----------------------------

Participants may add joints and actuators inside user_mechanism.xml.

For example:

    <body name="lid" pos="0 0 0.15">
      <joint
        name="lid_joint"
        type="hinge"
        axis="0 1 0"
        range="0 1.2"/>

      <geom
        type="box"
        size="0.10 0.08 0.005"/>
    </body>

    <actuator>
      <position
        name="lid_actuator"
        joint="lid_joint"
        kp="20"
        ctrlrange="0 1.2"
        ctrllimited="true"/>
    </actuator>

Because go2.xml attaches the model using prefix="user_", the names in the
full game become:

    user_lid_joint
    user_lid_actuator

user_side_go2.py automatically discovers user_* joint actuators.


PARTICIPANT SOFTWARE INTERFACE
------------------------------

The main software interface is intentionally:

    observation
        ->
    user_control(...)
        ->
    named actuator commands


INPUT
-----

get_observation() returns:

    observation["go2"]["joint_position"]
    observation["go2"]["joint_velocity"]

and, when participant mechanism joint actuators exist:

    observation["user_mechanism"]["joint_position"]
    observation["user_mechanism"]["joint_velocity"]


OUTPUT
------

user_control() returns a dictionary:

    {
        "FR_hip": command,
        "FR_thigh": command,
        ...
    }

A participant mechanism actuator can be added in exactly the same way:

    command["user_lid_actuator"] = 0.5

The field program resolves actuator names, checks that they belong to the
participant namespace, clips limited actuators to ctrlrange, and writes
the final values to data.ctrl.


CONTROL METHOD
--------------

The supplied crawl gait and integral compensation are examples only.

Participants may replace the implementation of user_control() with:

    - another gait generator,
    - state feedback,
    - PID,
    - MPC,
    - reinforcement learning,
    - a learned policy,
    - or another control method.

The field program does not need to change.


FOUR-BALL SCORING TEST
----------------------

The old field-side four-ball force launcher is retained, but it is OFF by
default in v7 because yellow_1 now starts in the Go2-mounted sample box.

Press:

    d

to toggle the launcher.

The launcher applies forces only. It does not reposition balls and does
not award points directly.


FULL GAME RUN
-------------

Keep the existing directories required by go2.xml and the field:

    assets/

Then run:

    cd D:\home\Mujoco\IDC2026_CyberGame
    (* if you use the virtual environment, run .\.venv\Scripts\Activate.ps1 before conducting run_match.py)
    py .\run_match.py


KEYS
----

    r : reset the match
    d : four-ball scoring-test launcher ON/OFF
    v : score-gate visualization ON/OFF
    g : supplied example Go2 gait ON/OFF
    p : supplied example integral compensation ON/OFF


FILES PARTICIPANTS SHOULD EDIT
------------------------------

Primary participant files:

    user_side_go2.py
    user_mechanism.xml

Organizer-side files should normally remain unchanged:

    field_side.py
    scene_IDC2026.xml
    go2.xml
    run_match.py
