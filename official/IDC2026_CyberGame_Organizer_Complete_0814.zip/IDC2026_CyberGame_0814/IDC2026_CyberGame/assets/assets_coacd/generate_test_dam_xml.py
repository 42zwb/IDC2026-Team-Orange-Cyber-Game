import os

OBJ_DIR = "."
OUTPUT_XML = "test_dam_coacd.xml"

obj_files = sorted(
    f for f in os.listdir(OBJ_DIR)
    if f.startswith("test_dam_part_") and f.endswith(".obj")
)

print(f"Found {len(obj_files)} OBJ files")

with open(OUTPUT_XML, "w") as f:

    f.write("<!-- Auto-generated COACD collision model -->\n\n")

    # ---------------------------
    # Asset
    # ---------------------------
    f.write("<asset>\n")

    # 元STL（可視化用）
    f.write('    <mesh name="test_dam_visual" file="../assets/test_dam.STL"/>\n')

    # COACD凸包
    for obj in obj_files:
        mesh_name = os.path.splitext(obj)[0]
        f.write(
            f'    <mesh name="{mesh_name}" file="{obj}"/>\n'
        )

    f.write("</asset>\n\n")

    # ---------------------------
    # Worldbody
    # ---------------------------
    f.write("<worldbody>\n")
    f.write('    <body name="test_dam" pos="0 0 0">\n\n')

    # 可視化モデル
    f.write(
        '        <geom '
        'type="mesh" '
        'mesh="test_dam_visual" '
        'contype="0" '
        'conaffinity="0" '
        'rgba="0.7 0.7 0.7 1" '
        'euler="1.5708 1.5708 0"/>\n\n'
    )

    # 衝突モデル
    for obj in obj_files:

        mesh_name = os.path.splitext(obj)[0]

        f.write(
            '        <geom '
            f'type="mesh" '
            f'mesh="{mesh_name}" '
            'group="3" '
            'euler="1.5708 1.5708 0"/>\n'
        )

    f.write("\n    </body>\n")
    f.write("</worldbody>\n")

print(f"Generated: {OUTPUT_XML}")