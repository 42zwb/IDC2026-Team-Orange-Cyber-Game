import os
import trimesh
import coacd

INPUT_FILE = "../assets/test_dam.STL"
OUTPUT_DIR = "."

print("Loading mesh...")
mesh = trimesh.load(INPUT_FILE, force="mesh")

print("Vertices:", len(mesh.vertices))
print("Faces   :", len(mesh.faces))

coacd_mesh = coacd.Mesh(
    mesh.vertices,
    mesh.faces
)

print("Running COACD...")

parts = coacd.run_coacd(
    coacd_mesh,
    threshold=0.001,
    resolution=50000,
    mcts_iterations=1000,
    mcts_max_depth=5,
    max_convex_hull=-1
)

print("Convex hulls:", len(parts))

for i, part in enumerate(parts):

    vertices = part[0]
    faces = part[1]

    hull_mesh = trimesh.Trimesh(
        vertices=vertices,
        faces=faces,
        process=False
    )

    filename = os.path.join(
        OUTPUT_DIR,
        f"test_dam_part_{i:03d}.obj"
    )

    hull_mesh.export(filename)

    print("Saved:", filename)

print("Done.")