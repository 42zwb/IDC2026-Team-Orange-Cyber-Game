import os

# ----------------------------------------------------------------
# 設定
# ----------------------------------------------------------------
# OBJファイルが保存されているディレクトリ
OBJ_DIR = "assets_coacd"
# 元のSTLファイル（可視化用）のパス
VISUAL_STL_PATH = "assets/test_stair.STL"
# 出力するXMLファイル名
OUTPUT_XML = "test_stair_coacd.xml"

# assets_coacd ディレクトリ内から該当するOBJファイルをソートして取得
obj_files = sorted(
    f for f in os.listdir(OBJ_DIR)
    if f.startswith("test_stair_part_") and f.endswith(".obj")
)

print(f"Found {len(obj_files)} OBJ files in '{OBJ_DIR}'")

# ----------------------------------------------------------------
# XML生成処理
# ----------------------------------------------------------------
with open(OUTPUT_XML, "w", encoding="utf-8") as f:

    f.write("\n\n")

    # ---------------------------
    # Asset セクション
    # ---------------------------
    f.write("<asset>\n")

    # 元STL（可視化用）の定義
    f.write(f'    <mesh name="test_stair_visual" file="{VISUAL_STL_PATH}"/>\n')

    # COACDで生成された凸包群の定義
    for obj in obj_files:
        mesh_name = os.path.splitext(obj)[0]
        # XMLから見た相対パス（assets_coacd/test_stair_part_xxx.obj）を指定
        xml_file_path = os.path.join(OBJ_DIR, obj).replace(os.sep, '/')
        f.write(
            f'    <mesh name="{mesh_name}" file="{xml_file_path}"/>\n'
        )

    f.write("</asset>\n\n")

    # ---------------------------
    # Worldbody セクション
    # ---------------------------
    f.write("<worldbody>\n")
    f.write('    <body name="test_stair" pos="0 0 0">\n\n')

    # 可視化モデル（見た目用：衝突判定はオフ contype="0" conaffinity="0"）
    f.write(
        '        <geom '
        'type="mesh" '
        'mesh="test_stair_visual" '
        'contype="0" '
        'conaffinity="0" '
        'rgba="0.7 0.7 0.7 1" '
        'euler="1.5708 1.5708 0"/>\n\n'
    )

    # 衝突モデル（物理判定用：group="3" で非表示にできるように設定）
    for obj in obj_files:
        mesh_name = os.path.splitext(obj)[0]
        f.write(
            '        <geom '
            'type="mesh" '
            f'mesh="{mesh_name}" '
            'group="3" '
            'euler="1.5708 1.5708 0"/>\n'
        )

    f.write("\n    </body>\n")
    f.write("</worldbody>\n")

print(f"Generated: {OUTPUT_XML}")