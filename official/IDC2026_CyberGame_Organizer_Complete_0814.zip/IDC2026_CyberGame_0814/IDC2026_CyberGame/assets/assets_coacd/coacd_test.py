import trimesh
import coacd

mesh = trimesh.load("../assets/dam.STL", force="mesh")

coacd_mesh = coacd.Mesh(
    mesh.vertices,
    mesh.faces
)

parts = coacd.run_coacd(coacd_mesh)

print(type(parts))
print(len(parts))
print(type(parts[0]))
print(parts[0])