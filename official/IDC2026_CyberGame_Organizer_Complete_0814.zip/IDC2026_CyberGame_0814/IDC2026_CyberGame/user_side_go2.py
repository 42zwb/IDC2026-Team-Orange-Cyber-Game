import numpy as np
import mujoco


# ============================================================
# IDC2026 CYBER GAME - PARTICIPANT PROGRAM
# ============================================================
#
# This file contains the participant-editable part of the Cyber Game.
#
# The participant should first understand only the following interface:
#
#     1. What does the field provide?
#     2. What does the participant return?
#
# ----------------------------------------------------------------
# WHAT THE FIELD PROVIDES
# ----------------------------------------------------------------
#
# At every simulation step, field_side.py calls:
#
#     controller.compute_control(sim_time, dt)
#
# The current MuJoCo state is available through:
#
#     self.model
#     self.data
#
# This class converts the relevant part of that raw state into the
# participant-friendly dictionary returned by:
#
#     get_observation()
#
# The supplied observation currently contains:
#
#     observation["go2"]["joint_position"]
#     observation["go2"]["joint_velocity"]
#
# and, when the participant mechanism contains actuated joints:
#
#     observation["user_mechanism"]["joint_position"]
#     observation["user_mechanism"]["joint_velocity"]
#
# The field also provides semantic Cyber Game information:
#
#     observation["field"]["remaining_time_s"]
#
#     observation["field"]["goals"]["red_1"]["color"]
#     observation["field"]["goals"]["red_2"]["color"]
#     observation["field"]["goals"]["blue_1"]["color"]
#     observation["field"]["goals"]["blue_2"]["color"]
#
# Each goal entry also contains the fixed world position of the scoring
# opening.
#
# This is intentionally a symbolic field-sensing interface rather than a
# camera image. Computer vision is therefore not required for the basic
# sample competition interface.
#
# ----------------------------------------------------------------
# WHAT THE PARTICIPANT RETURNS
# ----------------------------------------------------------------
#
# The main participant control function is:
#
#     user_control(observation, sim_time, dt)
#
# It returns a dictionary:
#
#     {
#         actuator_name: command_value,
#         ...
#     }
#
# For the current Go2 model, the 12 Go2 actuators are MuJoCo position
# actuators, so each command value is a target joint angle [rad].
#
# Any actuator added in user_mechanism.xml is also available to the
# participant. Because the mechanism is attached with prefix="user_",
# those actuator names begin with:
#
#     user_
#
# Example:
#
#     command["user_lid_actuator"] = 0.5
#
# ----------------------------------------------------------------
# WHAT THE FIELD KEEPS PRIVATE / FIXED
# ----------------------------------------------------------------
#
# This participant file does NOT:
#
#     - call mujoco.mj_step()
#     - modify RED or BLUE scores
#     - decide whether a goal passage is valid
#     - control the match timer
#     - randomize the goal colors
#     - modify the scoreboards
#
# Goal randomization remains organizer-side. After randomization, the
# resulting field state is supplied read-only through
# observation["field"].
#
# This keeps the game rules fixed while allowing the simulated robot to
# receive the field information required for strategy and control.
#
# ----------------------------------------------------------------
# CONTROL METHOD
# ----------------------------------------------------------------
#
# No particular control method is required.
#
# The supplied crawl gait, inverse kinematics, position-servo gains, and
# integral compensation are only an example implementation.
#
# Participants may replace the control algorithm with, for example:
#
#     - another gait generator
#     - state feedback
#     - PID
#     - MPC
#     - reinforcement learning
#     - a learned policy
#     - any other participant-designed method
#
# The important requirement is only that user_control() returns valid
# actuator commands in the required dictionary format.
# ============================================================


# ============================================================
# OPTIONAL PARTICIPANT SETTING - GO2 INITIAL STATE
# ============================================================
#
# This block defines the INITIAL STATE of the complete Go2 system.
#
# It is used only when the field is reset. It is NOT part of the
# feedback-control algorithm.
#
# The Go2 base_link is connected to the world by a MuJoCo free joint.
# A free joint has:
#
#     qpos = [x, y, z, qw, qx, qy, qz]
#
#     qvel = [vx, vy, vz, wx, wy, wz]
#
# Therefore the participant can specify:
#
# position
#     World position of base_link [x, y, z] [m].
#
# quaternion
#     World orientation of base_link [w, x, y, z].
#
#     The quaternion is automatically normalized before it is applied.
#
#     Example: a yaw rotation theta about the world Z axis can be written
#     as:
#
#         theta = np.deg2rad(90.0)
#
#         quaternion = np.array([
#             np.cos(theta / 2.0),
#             0.0,
#             0.0,
#             np.sin(theta / 2.0),
#         ])
#
# linear_velocity
#     Initial translational velocity [vx, vy, vz] [m/s].
#
# angular_velocity
#     Initial angular velocity [wx, wy, wz] [rad/s].
#
# ----------------------------------------------------------------
# RELATION TO THE PARTICIPANT MECHANISM
# ----------------------------------------------------------------
#
# user_mechanism.xml is rigidly attached to Go2 base_link.
#
# Therefore:
#
#     changing the Go2 initial pose
#             ->
#     moves/rotates the participant mechanism
#             ->
#     moves/rotates mechanism sites such as user_ball_slot_1
#
# A ball initialized from such a site is placed AFTER the Go2 initial
# pose has been applied. This guarantees that the ball remains correctly
# positioned relative to the participant mechanism.
#
# ----------------------------------------------------------------
# RESET ORDER
# ----------------------------------------------------------------
#
# The field applies reset conditions in the following order:
#
#     1. reset the MuJoCo state
#     2. apply GO2_INITIAL_STATE to base_link
#     3. apply the initial Go2 leg-joint posture
#     4. update MuJoCo forward kinematics
#     5. resolve mechanism sites such as user_ball_slot_1
#     6. place the balls
#     7. randomize the field goal colors
#     8. start the match
#
# Only the initial state is set here. After the match starts, the Go2
# base moves according to the MuJoCo physics and participant actuator
# commands.
# ============================================================

GO2_INITIAL_STATE = {
    "position": np.array(
        [-2.9, 3.3, 0.645],
        dtype=float,
    ),

    "quaternion": np.array(
        [1.0, 0.0, 0.0, 0.0],
        dtype=float,
    ),

    "linear_velocity": np.array(
        [0.0, 0.0, 0.0],
        dtype=float,
    ),

    "angular_velocity": np.array(
        [0.0, 0.0, 0.0],
        dtype=float,
    ),
}


# ============================================================
# OPTIONAL PARTICIPANT SETTING - BALL INITIAL CONDITIONS
# ============================================================
#
# A ball can be placed either:
#
#   1. at an absolute world position:
#
#          "position": np.array([x, y, z])
#
#   2. relative to a named MuJoCo site:
#
#          "site": "user_ball_slot_1"
#
#      The sample yellow_1 ball uses this method. The named site is
#      defined inside user_mechanism.xml, so the ball remains aligned
#      with the participant mechanism even if the Go2 start position or
#      mechanism geometry changes.
#
# These settings are used only at reset. They are not feedback control.
# ============================================================

BALL_INITIAL_CONDITIONS = {
    # Sample: one yellow ball inside the participant box on the Go2 back.
    "yellow_1": {
        "site": "user_ball_slot_1",
        "position_offset": np.array(
            [0.0, 0.0, 0.0],
            dtype=float,
        ),
        "quaternion": np.array(
            [1.0, 0.0, 0.0, 0.0],
            dtype=float,
        ),
        "linear_velocity": np.zeros(
            3,
            dtype=float,
        ),
        "angular_velocity": np.zeros(
            3,
            dtype=float,
        ),
    },

    # The remaining three balls keep simple world-coordinate examples.
    "white_1": {
        "position": np.array(
            [-0.21, 0.52, 0.50],
            dtype=float,
        ),
        "quaternion": np.array(
            [1.0, 0.0, 0.0, 0.0],
            dtype=float,
        ),
        "linear_velocity": np.zeros(
            3,
            dtype=float,
        ),
        "angular_velocity": np.zeros(
            3,
            dtype=float,
        ),
    },

    "yellow_2": {
        "position": np.array(
            [0.19, 0.72, 0.50],
            dtype=float,
        ),
        "quaternion": np.array(
            [1.0, 0.0, 0.0, 0.0],
            dtype=float,
        ),
        "linear_velocity": np.zeros(
            3,
            dtype=float,
        ),
        "angular_velocity": np.zeros(
            3,
            dtype=float,
        ),
    },

    "white_2": {
        "position": np.array(
            [0.49, 0.92, 0.50],
            dtype=float,
        ),
        "quaternion": np.array(
            [1.0, 0.0, 0.0, 0.0],
            dtype=float,
        ),
        "linear_velocity": np.zeros(
            3,
            dtype=float,
        ),
        "angular_velocity": np.zeros(
            3,
            dtype=float,
        ),
    },
}


class Go2UserController:
    """Participant-side controller.

    Read this class from top to bottom.

    Public participant interface:
        1. get_observation()
        2. compute_control()
        3. user_control()

    Reset / match interface:
        4. initial_robot_state()
        5. initial_ball_state()
        6. initial_joint_state()
        7. reset()
        8. handle_key()

    Everything after that is infrastructure or the supplied example
    controller and may be replaced.
    """

    # ========================================================
    # 1. INITIALIZATION
    # ========================================================

    def __init__(
        self,
        model,
        data,
    ):
        """Receive the field-owned MuJoCo model and current state."""

        # field_side.py owns the actual MuJoCo model and state.
        # This controller receives references to those same objects so it can
        # read the current state while computing commands.
        #
        # Creating another MjData here would create a separate simulation
        # state and would therefore be incorrect.
        self.model = model
        self.data = data

        # Discover the 12 Go2 leg actuators by name instead of assuming
        # fixed actuator indices. This keeps the participant interface valid
        # even when user_mechanism.xml adds additional actuators.
        self.go2_joints = (
            self._find_go2_leg_actuators()
        )

        self.go2_joint_index = {
            item["joint_name"]: k
            for k, item in enumerate(
                self.go2_joints
            )
        }

        self.user_mechanism_joints = (
            self._find_user_mechanism_joint_actuators()
        )

        self._initialize_example_controller()

    # ========================================================
    # 2. WHAT THE PARTICIPANT RECEIVES
    # ========================================================

    def get_observation(
        self,
        field_observation,
    ):
        """Return a participant-friendly observation dictionary.

        Returns
        -------
        observation["go2"]["joint_position"]
            Dictionary:
                actuator_name -> joint angle [rad]

        observation["go2"]["joint_velocity"]
            Dictionary:
                actuator_name -> joint rate [rad/s]

        observation["user_mechanism"]["joint_position"]
            Joint positions for participant actuators whose compiled
            names begin with "user_".

        observation["user_mechanism"]["joint_velocity"]
            Corresponding joint rates.

        observation["field"]
            Semantic field information supplied by field_side.py.

            Important entries include:

                observation["field"]["remaining_time_s"]

                observation["field"]["goals"]["red_1"]["color"]
                observation["field"]["goals"]["red_2"]["color"]
                observation["field"]["goals"]["blue_1"]["color"]
                observation["field"]["goals"]["blue_2"]["color"]

            Goal colors are returned as the strings:

                "yellow"
                "white"

            The BLUE arrangement is the mirror image of RED, but both
            sides are included explicitly in the observation.

        The sample box has no joints, so the user_mechanism dictionaries
        are empty. If a participant later adds a hinge/actuator to
        user_mechanism.xml, it appears here automatically.
        """

        go2_q = {}
        go2_dq = {}

        for item in self.go2_joints:
            name = item[
                "actuator_name"
            ]

            go2_q[name] = float(
                self.data.qpos[
                    item["qpos_adr"]
                ]
            )

            go2_dq[name] = float(
                self.data.qvel[
                    item["qvel_adr"]
                ]
            )

        user_q = {}
        user_dq = {}

        for item in self.user_mechanism_joints:
            name = item[
                "actuator_name"
            ]

            user_q[name] = float(
                self.data.qpos[
                    item["qpos_adr"]
                ]
            )

            user_dq[name] = float(
                self.data.qvel[
                    item["qvel_adr"]
                ]
            )

        return {
            "go2": {
                "joint_position": go2_q,
                "joint_velocity": go2_dq,
            },
            "user_mechanism": {
                "joint_position": user_q,
                "joint_velocity": user_dq,
            },
            "field": field_observation,
        }

    # ========================================================
    # 3. WHAT THE PARTICIPANT RETURNS
    # ========================================================

    def compute_control(
        self,
        sim_time,
        dt,
        field_observation,
    ):
        """Return named actuator commands for one simulation step.

        field_side.py calls this function.

        Parameters
        ----------
        sim_time
            Current MuJoCo simulation time [s].

        dt
            MuJoCo simulation step [s].

        field_observation
            Read-only semantic field information prepared by field_side.py.
            It contains current goal colors, goal positions, Start B
            dimensions, and remaining match time.

        The participant-facing return format is:

            {
                "FR_hip": command,
                "FR_thigh": command,
                ...
                "user_some_actuator": command,
            }

        Go2 actuator names are fixed by go2.xml.

        Any actuator defined in user_mechanism.xml receives the "user_"
        prefix when attached to Go2. For example:

            actuator name="lid_actuator"

        becomes:

            "user_lid_actuator"

        in the full game model.
        """

        observation = (
            self.get_observation(
                field_observation
            )
        )

        command = self.user_control(
            observation=observation,
            sim_time=sim_time,
            dt=dt,
        )

        if not isinstance(
            command,
            dict,
        ):
            raise TypeError(
                "user_control() must return a dict: "
                "{actuator_name: command_value}"
            )

        return command

    # ========================================================
    # 4. MAIN PARTICIPANT CONTROL FUNCTION
    # ========================================================

    def user_control(
        self,
        observation,
        sim_time,
        dt,
    ):
        """Implement the participant control algorithm here.

        INPUT
        -----
        observation
            Current Go2 state, participant-mechanism state, and semantic
            field information.

            Example:

                red_1_color = (
                    observation[
                        "field"
                    ][
                        "goals"
                    ][
                        "red_1"
                    ][
                        "color"
                    ]
                )

        sim_time
            Current simulation time [s].

        dt
            Simulation step [s].

        OUTPUT
        ------
        command
            Dictionary:
                actuator_name -> command_value

        ----------------------------------------------------------------
        IMPORTANT
        ----------------------------------------------------------------

        The code below is only the supplied example.

        It uses:
            - a hand-designed crawl gait,
            - inverse kinematics,
            - MuJoCo position servos,
            - optional integral compensation.

        The participant may replace it with:
            - another gait,
            - state feedback,
            - PID,
            - MPC,
            - reinforcement learning,
            - a learned policy,
            - or any other controller.

        The field program does not need to change.
        """

        q = np.array(
            [
                observation[
                    "go2"
                ][
                    "joint_position"
                ][
                    item["actuator_name"]
                ]
                for item in self.go2_joints
            ],
            dtype=float,
        )

        q_des, integrate_mask = (
            self._example_desired_joint_angle(
                sim_time
            )
        )

        q_cmd = (
            self._example_integral_compensation(
                q_des=q_des,
                q=q,
                dt=dt,
                integrate_mask=integrate_mask,
            )
        )

        q_cmd = (
            self._clip_go2_position_command(
                q_cmd
            )
        )

        command = {
            item["actuator_name"]: float(
                q_cmd[k]
            )
            for k, item in enumerate(
                self.go2_joints
            )
        }

        # ------------------------------------------------------------
        # Example for a future participant mechanism actuator:
        #
        # command["user_lid_actuator"] = 0.5
        #
        # The supplied sample box is passive, so no user_* actuator
        # command is required here.
        # ------------------------------------------------------------

        return command

    # ========================================================
    # 5. RESET / INITIAL-CONDITION INTERFACE
    # ========================================================

    def initial_robot_state(self):
        """Return the participant-defined initial state of Go2 base_link.

        This function is part of the reset interface between the
        participant program and field_side.py.

        It does NOT directly write to MuJoCo. Instead, it returns a clean,
        validated copy of GO2_INITIAL_STATE. field_side.py is responsible
        for applying that state to the Go2 free joint.

        Why use this interface instead of writing self.data.qpos here?
        --------------------------------------------------------------
        Keeping all writes to the physical simulation inside field_side.py
        makes the responsibility boundary explicit:

            user_side_go2.py
                defines the participant's requested initial condition

            field_side.py
                validates ownership of the simulation and applies it

        This is also consistent with the main control interface, where the
        participant returns actuator commands rather than advancing the
        simulation directly.

        Returns
        -------
        state : dict

            state["position"]
                World position of base_link [x, y, z] [m].

            state["quaternion"]
                World orientation [w, x, y, z].

            state["linear_velocity"]
                Initial world linear velocity [vx, vy, vz] [m/s].

            state["angular_velocity"]
                Initial world angular velocity [wx, wy, wz] [rad/s].

        The quaternion is normalized here so that the field always receives
        a valid unit quaternion.
        """

        position = np.asarray(
            GO2_INITIAL_STATE["position"],
            dtype=float,
        ).copy()

        quaternion = np.asarray(
            GO2_INITIAL_STATE["quaternion"],
            dtype=float,
        ).copy()

        linear_velocity = np.asarray(
            GO2_INITIAL_STATE.get(
                "linear_velocity",
                [0.0, 0.0, 0.0],
            ),
            dtype=float,
        ).copy()

        angular_velocity = np.asarray(
            GO2_INITIAL_STATE.get(
                "angular_velocity",
                [0.0, 0.0, 0.0],
            ),
            dtype=float,
        ).copy()

        # Check dimensions here so configuration mistakes are reported
        # before the field attempts to write into the MuJoCo free joint.
        if position.shape != (3,):
            raise ValueError(
                "GO2_INITIAL_STATE['position'] "
                "must have 3 elements."
            )

        if quaternion.shape != (4,):
            raise ValueError(
                "GO2_INITIAL_STATE['quaternion'] "
                "must have 4 elements."
            )

        if linear_velocity.shape != (3,):
            raise ValueError(
                "GO2_INITIAL_STATE['linear_velocity'] "
                "must have 3 elements."
            )

        if angular_velocity.shape != (3,):
            raise ValueError(
                "GO2_INITIAL_STATE['angular_velocity'] "
                "must have 3 elements."
            )

        quaternion_norm = np.linalg.norm(
            quaternion
        )

        if quaternion_norm <= 1.0e-12:
            raise ValueError(
                "GO2_INITIAL_STATE['quaternion'] "
                "must not be zero."
            )

        # MuJoCo free-joint orientation must be represented by a unit
        # quaternion. Normalizing here also allows participants to use
        # rounded quaternion values safely.
        quaternion /= quaternion_norm

        return {
            "position": position,
            "quaternion": quaternion,
            "linear_velocity": linear_velocity,
            "angular_velocity": angular_velocity,
        }

    def initial_ball_state(self):
        """Return participant-defined ball initial conditions.

        This is an initial-condition interface, not the feedback-control
        algorithm. Site-based placement is passed through to field_side.py,
        which resolves the site world position after the Go2 reset posture
        has been applied.
        """

        state = {}

        for (
            ball_name,
            config,
        ) in (
            BALL_INITIAL_CONDITIONS.items()
        ):
            result = {}

            if "site" in config:
                result["site"] = str(
                    config["site"]
                )

                result[
                    "position_offset"
                ] = np.asarray(
                    config.get(
                        "position_offset",
                        [0.0, 0.0, 0.0],
                    ),
                    dtype=float,
                ).copy()

            elif "position" in config:
                result[
                    "position"
                ] = np.asarray(
                    config["position"],
                    dtype=float,
                ).copy()

            else:
                raise ValueError(
                    f"{ball_name}: specify "
                    "'position' or 'site'."
                )

            result[
                "quaternion"
            ] = np.asarray(
                config.get(
                    "quaternion",
                    [1.0, 0.0, 0.0, 0.0],
                ),
                dtype=float,
            ).copy()

            result[
                "linear_velocity"
            ] = np.asarray(
                config.get(
                    "linear_velocity",
                    [0.0, 0.0, 0.0],
                ),
                dtype=float,
            ).copy()

            result[
                "angular_velocity"
            ] = np.asarray(
                config.get(
                    "angular_velocity",
                    [0.0, 0.0, 0.0],
                ),
                dtype=float,
            ).copy()

            state[
                ball_name
            ] = result

        return state

    def initial_joint_state(self):
        """Return the supplied example Go2 reset posture."""

        return [
            (
                item["qpos_adr"],
                item["qvel_adr"],
                item["actuator_id"],
                float(
                    self.q_stand[k]
                ),
            )
            for k, item in enumerate(
                self.go2_joints
            )
        ]

    def reset(self):
        """Reset only participant-controller internal memory."""

        self.integral_error[:] = 0.0

    def handle_key(
        self,
        key,
    ):
        """Handle optional keys used by the supplied example."""

        if key == "g":
            self.gait_enabled = (
                not self.gait_enabled
            )

            self.integral_error[:] = 0.0

            print(
                "[USER] Example gait: "
                f"{'ON' if self.gait_enabled else 'OFF'}"
            )

            return True

        if key == "p":
            self.pid_integral_enabled = (
                not
                self.pid_integral_enabled
            )

            self.integral_error[:] = 0.0

            print(
                "[USER] Example integral compensation: "
                f"{'ON' if self.pid_integral_enabled else 'OFF'}"
            )

            return True

        return False

    # ========================================================
    # 6. INTERNAL MODEL INTERFACE
    # ========================================================

    def _find_go2_leg_actuators(self):
        """Find the 12 Go2 leg joint actuators."""

        actuated_joints = []

        for actuator_id in range(
            self.model.nu
        ):
            actuator_name = (
                mujoco.mj_id2name(
                    self.model,
                    mujoco.mjtObj.mjOBJ_ACTUATOR,
                    actuator_id,
                )
            )

            if actuator_name is None:
                continue

            if not actuator_name.startswith(
                ("FR_", "FL_", "RR_", "RL_")
            ):
                continue

            if (
                self.model
                .actuator_trntype[
                    actuator_id
                ]
                != mujoco.mjtTrn.mjTRN_JOINT
            ):
                continue

            joint_id = int(
                self.model.actuator_trnid[
                    actuator_id,
                    0,
                ]
            )

            joint_name = (
                mujoco.mj_id2name(
                    self.model,
                    mujoco.mjtObj.mjOBJ_JOINT,
                    joint_id,
                )
            )

            actuated_joints.append(
                {
                    "actuator_id": actuator_id,
                    "actuator_name": actuator_name,
                    "joint_id": joint_id,
                    "joint_name": joint_name,
                    "qpos_adr": int(
                        self.model
                        .jnt_qposadr[
                            joint_id
                        ]
                    ),
                    "qvel_adr": int(
                        self.model
                        .jnt_dofadr[
                            joint_id
                        ]
                    ),
                }
            )

        if len(
            actuated_joints
        ) != 12:
            raise RuntimeError(
                "Go2 leg actuators: "
                f"expected 12, "
                f"found {len(actuated_joints)}"
            )

        return actuated_joints

    def _find_user_mechanism_joint_actuators(
        self,
    ):
        """Find participant mechanism joint actuators by the user_ prefix."""

        result = []

        for actuator_id in range(
            self.model.nu
        ):
            actuator_name = (
                mujoco.mj_id2name(
                    self.model,
                    mujoco.mjtObj.mjOBJ_ACTUATOR,
                    actuator_id,
                )
            )

            if (
                actuator_name is None
                or not actuator_name.startswith(
                    "user_"
                )
            ):
                continue

            if (
                self.model
                .actuator_trntype[
                    actuator_id
                ]
                != mujoco.mjtTrn.mjTRN_JOINT
            ):
                continue

            joint_id = int(
                self.model.actuator_trnid[
                    actuator_id,
                    0,
                ]
            )

            joint_name = (
                mujoco.mj_id2name(
                    self.model,
                    mujoco.mjtObj.mjOBJ_JOINT,
                    joint_id,
                )
            )

            result.append(
                {
                    "actuator_id": actuator_id,
                    "actuator_name": actuator_name,
                    "joint_id": joint_id,
                    "joint_name": joint_name,
                    "qpos_adr": int(
                        self.model
                        .jnt_qposadr[
                            joint_id
                        ]
                    ),
                    "qvel_adr": int(
                        self.model
                        .jnt_dofadr[
                            joint_id
                        ]
                    ),
                }
            )

        return result

    def _clip_go2_position_command(
        self,
        q_cmd,
    ):
        """Clip the supplied example Go2 commands to XML ctrlrange."""

        q_safe = np.asarray(
            q_cmd,
            dtype=float,
        ).copy()

        if q_safe.shape != (12,):
            raise ValueError(
                "The supplied Go2 example must "
                "return 12 joint commands."
            )

        for k, item in enumerate(
            self.go2_joints
        ):
            actuator_id = item[
                "actuator_id"
            ]

            if (
                self.model
                .actuator_ctrllimited[
                    actuator_id
                ]
            ):
                low, high = (
                    self.model
                    .actuator_ctrlrange[
                        actuator_id
                    ]
                )

                q_safe[k] = np.clip(
                    q_safe[k],
                    low,
                    high,
                )

        return q_safe

    # ========================================================
    # 7. SUPPLIED EXAMPLE CONTROL IMPLEMENTATION
    # ========================================================
    #
    # Everything below is only an example. Participants may replace
    # this entire section while preserving the public interface above.
    # ========================================================

    def _initialize_example_controller(
        self,
    ):
        """Initialize the supplied crawl/PID example."""

        self.KP_HIP = 60.0
        self.KD_HIP = 4.0

        self.KP_THIGH = 90.0
        self.KD_THIGH = 6.0

        self.KP_CALF = 90.0
        self.KD_CALF = 6.0

        self._example_configure_position_actuator_gains()

        self.position_kp = np.array(
            [
                float(
                    self.model
                    .actuator_gainprm[
                        item[
                            "actuator_id"
                        ],
                        0,
                    ]
                )
                for item in self.go2_joints
            ],
            dtype=float,
        )

        self.STAND_HIP = 0.0
        self.STAND_THIGH = 0.75
        self.STAND_CALF = -1.50

        self.q_stand = (
            self._example_make_standing_posture()
        )

        self.integral_gain = np.zeros(
            12,
            dtype=float,
        )

        self.integral_torque_limit = np.zeros(
            12,
            dtype=float,
        )

        for k, item in enumerate(
            self.go2_joints
        ):
            name = item[
                "joint_name"
            ]

            if "_hip_joint" in name:
                self.integral_gain[k] = 0.5
                self.integral_torque_limit[k] = 0.5

            elif "_thigh_joint" in name:
                self.integral_gain[k] = 3.0
                self.integral_torque_limit[k] = 2.0

            elif "_calf_joint" in name:
                self.integral_gain[k] = 3.0
                self.integral_torque_limit[k] = 2.0

        self.INTEGRATION_ERROR_LIMIT = 0.25

        self.integral_error = np.zeros(
            12,
            dtype=float,
        )

        self.pid_integral_enabled = True

        self.L_THIGH = 0.213
        self.L_CALF = 0.213

        (
            self.NOMINAL_FOOT_X,
            self.NOMINAL_FOOT_Z,
        ) = (
            self._example_leg_forward_kinematics(
                self.STAND_THIGH,
                self.STAND_CALF,
            )
        )

        self.STAND_HOLD_TIME = 1.0
        self.GAIT_BLEND_TIME = 0.30
        self.GAIT_CYCLE = 2.40
        self.SWING_RATIO = 0.25
        self.STEP_LENGTH = -0.055
        self.FOOT_LIFT = 0.080
        self.HIP_WEIGHT_SHIFT = 0.055
        self.HIP_SHIFT_SIGN = 1.0

        self.LEG_PHASE_OFFSET = {
            "FR": 0.00,
            "RL": 0.25,
            "FL": 0.50,
            "RR": 0.75,
        }

        self.gait_enabled = True

    def _example_configure_position_actuator_gains(
        self,
    ):
        """Set P-D gains for the supplied Go2 position-servo example."""

        for item in self.go2_joints:
            actuator_id = item[
                "actuator_id"
            ]

            name = item[
                "joint_name"
            ]

            if "_hip_joint" in name:
                kp, kd = (
                    self.KP_HIP,
                    self.KD_HIP,
                )

            elif "_thigh_joint" in name:
                kp, kd = (
                    self.KP_THIGH,
                    self.KD_THIGH,
                )

            elif "_calf_joint" in name:
                kp, kd = (
                    self.KP_CALF,
                    self.KD_CALF,
                )

            else:
                continue

            self.model.actuator_gainprm[
                actuator_id,
                0,
            ] = kp

            self.model.actuator_biasprm[
                actuator_id,
                1,
            ] = -kp

            self.model.actuator_biasprm[
                actuator_id,
                2,
            ] = -kd

    def _example_make_standing_posture(
        self,
    ):
        """Build the supplied example standing posture."""

        q_stand = np.zeros(
            12,
            dtype=float,
        )

        for k, item in enumerate(
            self.go2_joints
        ):
            name = item[
                "joint_name"
            ]

            if "_hip_joint" in name:
                q_stand[k] = (
                    self.STAND_HIP
                )

            elif "_thigh_joint" in name:
                q_stand[k] = (
                    self.STAND_THIGH
                )

            elif "_calf_joint" in name:
                q_stand[k] = (
                    self.STAND_CALF
                )

        return q_stand

    def _example_integral_compensation(
        self,
        q_des,
        q,
        dt,
        integrate_mask,
    ):
        """Apply the optional integral term used by the example."""

        q_des = np.asarray(
            q_des,
            dtype=float,
        )

        q = np.asarray(
            q,
            dtype=float,
        )

        integrate_mask = np.asarray(
            integrate_mask,
            dtype=bool,
        )

        error = q_des - q

        if not self.pid_integral_enabled:
            self.integral_error[:] = 0.0
            return q_des

        self.integral_error[
            ~integrate_mask
        ] = 0.0

        valid = (
            integrate_mask
            & (
                np.abs(error)
                <= self.INTEGRATION_ERROR_LIMIT
            )
        )

        self.integral_error[
            valid
        ] += (
            error[valid]
            * dt
        )

        tau_i = (
            self.integral_gain
            * self.integral_error
        )

        tau_i = np.clip(
            tau_i,
            -self.integral_torque_limit,
            self.integral_torque_limit,
        )

        nonzero_gain = (
            self.integral_gain
            > 0.0
        )

        self.integral_error[
            nonzero_gain
        ] = (
            tau_i[nonzero_gain]
            / self.integral_gain[
                nonzero_gain
            ]
        )

        return (
            q_des
            + tau_i
            / self.position_kp
        )

    def _example_leg_forward_kinematics(
        self,
        thigh_angle,
        calf_angle,
    ):
        """Return planar foot position [x, z]."""

        x_foot = (
            -self.L_THIGH
            * np.sin(
                thigh_angle
            )
            - self.L_CALF
            * np.sin(
                thigh_angle
                + calf_angle
            )
        )

        z_foot = (
            -self.L_THIGH
            * np.cos(
                thigh_angle
            )
            - self.L_CALF
            * np.cos(
                thigh_angle
                + calf_angle
            )
        )

        return (
            x_foot,
            z_foot,
        )

    def _example_leg_inverse_kinematics(
        self,
        x_foot,
        z_foot,
    ):
        """Solve the supplied example two-link planar IK."""

        x_aux = -x_foot
        z_aux = -z_foot

        radius_sq = (
            x_aux * x_aux
            + z_aux * z_aux
        )

        cos_calf = (
            radius_sq
            - self.L_THIGH**2
            - self.L_CALF**2
        ) / (
            2.0
            * self.L_THIGH
            * self.L_CALF
        )

        cos_calf = np.clip(
            cos_calf,
            -1.0,
            1.0,
        )

        calf_angle = (
            -np.arccos(
                cos_calf
            )
        )

        thigh_angle = (
            np.arctan2(
                x_aux,
                z_aux,
            )
            - np.arctan2(
                self.L_CALF
                * np.sin(
                    calf_angle
                ),
                self.L_THIGH
                + self.L_CALF
                * np.cos(
                    calf_angle
                ),
            )
        )

        return (
            thigh_angle,
            calf_angle,
        )

    @staticmethod
    def _example_smoothstep(
        s,
    ):
        """Smooth 0-to-1 interpolation."""

        s = np.clip(
            s,
            0.0,
            1.0,
        )

        return (
            s * s
            * (3.0 - 2.0 * s)
        )

    def _example_swing_support_shift(
        self,
        local_swing_phase,
        leg_name,
    ):
        """Generate the supplied open-loop support-side hip shift."""

        u = np.clip(
            local_swing_phase,
            0.0,
            1.0,
        )

        if u < 0.20:
            magnitude = (
                self._example_smoothstep(
                    u / 0.20
                )
            )

        elif u < 0.80:
            magnitude = 1.0

        else:
            magnitude = (
                1.0
                - self._example_smoothstep(
                    (u - 0.80)
                    / 0.20
                )
            )

        side_sign = (
            -1.0
            if leg_name
            in ("FR", "RR")
            else 1.0
        )

        return (
            self.HIP_SHIFT_SIGN
            * side_sign
            * self.HIP_WEIGHT_SHIFT
            * magnitude
        )

    def _example_swing_foot_trajectory(
        self,
        u,
    ):
        """Generate one supplied example swing-foot trajectory."""

        half_step = (
            0.5
            * self.STEP_LENGTH
        )

        x_back = (
            self.NOMINAL_FOOT_X
            - half_step
        )

        x_front = (
            self.NOMINAL_FOOT_X
            + half_step
        )

        z_ground = (
            self.NOMINAL_FOOT_Z
        )

        z_up = (
            self.NOMINAL_FOOT_Z
            + self.FOOT_LIFT
        )

        if u < 0.20:
            return (
                x_back,
                z_ground,
                False,
            )

        if u < 0.35:
            s = (
                self._example_smoothstep(
                    (u - 0.20)
                    / 0.15
                )
            )

            return (
                x_back,
                z_ground
                + self.FOOT_LIFT
                * s,
                True,
            )

        if u < 0.65:
            s = (
                self._example_smoothstep(
                    (u - 0.35)
                    / 0.30
                )
            )

            return (
                x_back
                + self.STEP_LENGTH
                * s,
                z_up,
                True,
            )

        if u < 0.80:
            s = (
                self._example_smoothstep(
                    (u - 0.65)
                    / 0.15
                )
            )

            return (
                x_front,
                z_up
                - self.FOOT_LIFT
                * s,
                True,
            )

        return (
            x_front,
            z_ground,
            False,
        )

    def _example_foot_trajectory(
        self,
        cycle_phase,
        leg_name,
    ):
        """Return one supplied example foot target."""

        local_phase = (
            cycle_phase
            - self.LEG_PHASE_OFFSET[
                leg_name
            ]
        ) % 1.0

        half_step = (
            0.5
            * self.STEP_LENGTH
        )

        if (
            local_phase
            < self.SWING_RATIO
        ):
            u = (
                local_phase
                / self.SWING_RATIO
            )

            (
                x_foot,
                z_foot,
                is_airborne,
            ) = (
                self._example_swing_foot_trajectory(
                    u
                )
            )

            hip_shift = (
                self._example_swing_support_shift(
                    u,
                    leg_name,
                )
            )

            return (
                x_foot,
                z_foot,
                is_airborne,
                hip_shift,
            )

        stance_phase = (
            local_phase
            - self.SWING_RATIO
        ) / (
            1.0
            - self.SWING_RATIO
        )

        x_foot = (
            self.NOMINAL_FOOT_X
            + half_step
            - self.STEP_LENGTH
            * self._example_smoothstep(
                stance_phase
            )
        )

        return (
            x_foot,
            self.NOMINAL_FOOT_Z,
            False,
            0.0,
        )

    def _example_desired_joint_angle(
        self,
        t,
    ):
        """Generate desired joint angles for the supplied crawl example."""

        q_des = (
            self.q_stand.copy()
        )

        integrate_mask = np.ones(
            12,
            dtype=bool,
        )

        if (
            not self.gait_enabled
            or
            t < self.STAND_HOLD_TIME
        ):
            return (
                q_des,
                integrate_mask,
            )

        gait_time = (
            t
            - self.STAND_HOLD_TIME
        )

        cycle_phase = (
            gait_time
            / self.GAIT_CYCLE
        ) % 1.0

        blend = (
            self._example_smoothstep(
                gait_time
                / self.GAIT_BLEND_TIME
            )
        )

        common_hip_shift = 0.0

        for leg_name in (
            "FR",
            "FL",
            "RR",
            "RL",
        ):
            (
                x_gait,
                z_gait,
                is_airborne,
                hip_shift,
            ) = (
                self._example_foot_trajectory(
                    cycle_phase,
                    leg_name,
                )
            )

            if (
                abs(hip_shift)
                > abs(
                    common_hip_shift
                )
            ):
                common_hip_shift = (
                    hip_shift
                )

            x_cmd = (
                self.NOMINAL_FOOT_X
                + blend
                * (
                    x_gait
                    - self.NOMINAL_FOOT_X
                )
            )

            z_cmd = (
                self.NOMINAL_FOOT_Z
                + blend
                * (
                    z_gait
                    - self.NOMINAL_FOOT_Z
                )
            )

            (
                thigh_cmd,
                calf_cmd,
            ) = (
                self._example_leg_inverse_kinematics(
                    x_cmd,
                    z_cmd,
                )
            )

            hip_index = (
                self.go2_joint_index[
                    f"{leg_name}_hip_joint"
                ]
            )

            thigh_index = (
                self.go2_joint_index[
                    f"{leg_name}_thigh_joint"
                ]
            )

            calf_index = (
                self.go2_joint_index[
                    f"{leg_name}_calf_joint"
                ]
            )

            q_des[
                thigh_index
            ] = thigh_cmd

            q_des[
                calf_index
            ] = calf_cmd

            if is_airborne:
                integrate_mask[
                    hip_index
                ] = False

                integrate_mask[
                    thigh_index
                ] = False

                integrate_mask[
                    calf_index
                ] = False

        for leg_name in (
            "FR",
            "FL",
            "RR",
            "RL",
        ):
            hip_index = (
                self.go2_joint_index[
                    f"{leg_name}_hip_joint"
                ]
            )

            q_des[
                hip_index
            ] = (
                self.STAND_HIP
                + blend
                * common_hip_shift
            )

        return (
            q_des,
            integrate_mask,
        )
