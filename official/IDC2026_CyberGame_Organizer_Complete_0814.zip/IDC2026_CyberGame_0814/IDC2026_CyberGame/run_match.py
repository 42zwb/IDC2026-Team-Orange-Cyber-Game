# ============================================================
# IDC2026 Cyber Game launcher
# ============================================================
#
# Start this file only.
#
# field_side.py
#     Organizer-side simulation, physics, randomized goal condition,
#     scoring and scoreboards.
#
# user_side_go2.py
#     Participant observations, control, and ball initial conditions.
#
# user_mechanism.xml
#     Participant-editable mechanism attached to the Go2 base_link.
#
# Both run in one Python process and share the same MuJoCo model/data.
# ============================================================

from field_side import FieldRuntime
from user_side_go2 import Go2UserController


XML_PATH = "scene_IDC2026.xml"


def main():
    field = FieldRuntime(
        XML_PATH
    )

    user = Go2UserController(
        field.model,
        field.data,
    )

    field.attach_controller(
        user
    )

    field.run()


if __name__ == "__main__":
    main()
